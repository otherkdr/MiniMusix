import SwiftUI

struct LockScreenSurfaceView: View {
    @ObservedObject var store: NowPlayingStore
    @ObservedObject var presentation: MiniPlayerPresentationController
    var close: () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        ZStack(alignment: .topLeading) {
            LockScreenBackgroundView(track: store.currentTrack, tintStrength: store.settings.albumTintStrength)

            lockscreenContent

            VStack(spacing: 10) {
                GlassIconButton(
                    systemName: "xmark",
                    label: "Close Lockscreen Player",
                    tint: store.currentTrack?.dominantColor ?? .secondary,
                    size: 42,
                    action: close
                )

                GlassIconButton(
                    systemName: presentation.lockscreenLyricsVisible ? "quote.bubble.fill" : "quote.bubble",
                    label: presentation.lockscreenLyricsVisible ? "Hide Lyrics" : "Show Lyrics",
                    tint: store.currentTrack?.secondaryColor ?? .secondary,
                    size: 42
                ) {
                    animate {
                        presentation.toggleLockscreenLyrics()
                    }
                }
            }
            .padding(22)
            .transition(.scale(scale: 0.86, anchor: .topLeading).combined(with: .opacity))
        }
        .frame(width: presentation.lockscreenLyricsVisible ? 1024 : 684, height: 614)
        .clipShape(RoundedRectangle(cornerRadius: 36, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .strokeBorder(.white.opacity(0.16), lineWidth: 0.8)
                .allowsHitTesting(false)
        }
        .shadow(color: (store.currentTrack?.dominantColor ?? .secondary).opacity(0.16), radius: 28, y: 14)
        .animation(reduceMotion ? nil : .spring(response: 0.62, dampingFraction: 0.86), value: presentation.lockscreenLyricsVisible)
    }

    @ViewBuilder
    private var lockscreenContent: some View {
        if let track = store.currentTrack {
            HStack(spacing: presentation.lockscreenLyricsVisible ? 64 : 0) {
                musicGroup(track)
                    .frame(width: 500)
                    .offset(x: presentation.lockscreenLyricsVisible ? -18 : 0)

                if presentation.lockscreenLyricsVisible {
                    LockScreenLyricsView(
                        lyrics: store.lyrics,
                        elapsed: track.elapsed,
                        fontSize: store.settings.lyricFontSize,
                        missingLyricsMessage: store.settings.missingLyricsMessage
                    )
                    .frame(width: 390, height: 468)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.horizontal, presentation.lockscreenLyricsVisible ? 40 : 92)
            .padding(.top, 44)
            .padding(.bottom, 34)
        } else {
            idleState
        }
    }

    private func musicGroup(_ track: NowPlayingTrack) -> some View {
        VStack(spacing: 18) {
            Spacer(minLength: 0)

            LockScreenArtworkView(track: track, glow: store.settings.artworkGlow)

            VStack(spacing: 7) {
                Text(track.identity.title)
                    .font(.system(size: 28, weight: .semibold))
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.72)

                Text(track.identity.artist)
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.78)
            }
            .frame(maxWidth: 390)

            VStack(spacing: 7) {
                ProgressStrip(track: track, height: 5) { seconds in
                    store.seek(to: seconds)
                }
                TrackTimeRow(track: track)
            }
            .frame(width: 390)

            LockScreenControlsView(store: store)

            Spacer(minLength: 0)
        }
    }

    private var idleState: some View {
        VStack(spacing: 18) {
            MiniMusixLogo(size: 184)
            Text("Not Playing")
                .font(.system(size: 30, weight: .semibold))
            Text("Waiting for media")
                .font(.title3)
                .foregroundStyle(.secondary)
            GlassIconButton(systemName: "arrow.clockwise", label: "Refresh Playback", tint: .secondary, size: 48) {
                Task { await store.refreshMetadata() }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func animate(_ changes: @escaping () -> Void) {
        if reduceMotion {
            changes()
        } else {
            withAnimation(.spring(response: 0.58, dampingFraction: 0.86), changes)
        }
    }
}

struct LockScreenArtworkView: View {
    var track: NowPlayingTrack
    var glow: Bool

    var body: some View {
        AlbumArtworkView(track: track, size: 292, glow: glow)
            .shadow(color: track.dominantColor.opacity(glow ? 0.24 : 0), radius: 26, y: 14)
    }
}

struct LockScreenBackgroundView: View {
    var track: NowPlayingTrack?
    var tintStrength: Double

    var body: some View {
        let primary = track?.dominantColor ?? .secondary
        let secondary = track?.secondaryColor ?? Color(nsColor: .tertiaryLabelColor)

        ZStack {
            Rectangle()
                .fill(.ultraThinMaterial)

            LinearGradient(
                colors: [
                    primary.opacity(max(tintStrength * 1.55, 0.14)),
                    secondary.opacity(max(tintStrength * 1.1, 0.10)),
                    Color(nsColor: .windowBackgroundColor).opacity(0.28)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            RadialGradient(
                colors: [
                    secondary.opacity(max(tintStrength * 1.3, 0.12)),
                    .clear
                ],
                center: .bottomTrailing,
                startRadius: 40,
                endRadius: 560
            )
        }
        .ignoresSafeArea()
    }
}

struct LockScreenControlsView: View {
    @ObservedObject var store: NowPlayingStore

    var body: some View {
        TransportControls(store: store, prominent: true)
            .controlSize(.large)
    }
}

struct LockScreenLyricsView: View {
    var lyrics: LyricsPayload
    var elapsed: TimeInterval
    var fontSize: CGFloat
    var missingLyricsMessage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Lyrics")
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(.primary)

            switch lyrics {
            case .loading:
                LyricsLoadingView()
                    .frame(maxHeight: .infinity)
            case .synced(let lines):
                LockScreenSyncedLyricsView(lines: lines, elapsed: elapsed, fontSize: fontSize)
            case .plain(let text):
                ScrollView {
                    Text(text)
                        .font(.system(size: min(max(fontSize + 3, 23), 32), weight: .semibold))
                        .lineSpacing(8)
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
            case .unavailable:
                VStack(spacing: 14) {
                    Image(systemName: "text.bubble")
                        .font(.system(size: 42, weight: .semibold))
                    Text(missingLyricsMessage)
                        .font(.title3.weight(.semibold))
                        .multilineTextAlignment(.center)
                }
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .padding(.vertical, 28)
        .padding(.horizontal, 8)
    }
}

private struct LockScreenSyncedLyricsView: View {
    var lines: [SyncedLyricLine]
    var elapsed: TimeInterval
    var fontSize: CGFloat
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var currentIndex: Int {
        let adjustedElapsed = elapsed + 0.18
        guard let index = lines.lastIndex(where: { $0.time <= adjustedElapsed }) else { return 0 }
        return index
    }

    var body: some View {
        ZStack(alignment: .leading) {
            ForEach(displayLines) { line in
                let offset = relativeOffset(for: line)
                let isCurrent = offset == 0

                Text(line.text)
                    .font(.system(size: isCurrent ? currentFontSize : supportFontSize, weight: isCurrent ? .bold : .semibold))
                    .foregroundStyle(isCurrent ? .primary : .secondary)
                    .lineLimit(isCurrent ? 3 : 2)
                    .minimumScaleFactor(0.68)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .opacity(opacity(for: offset))
                    .scaleEffect(isCurrent ? 1.0 : 0.96, anchor: .leading)
                    .offset(y: yOffset(for: offset))
                    .blur(radius: isCurrent ? 0 : 0.18)
                    .contentTransition(.opacity)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        .clipped()
        .animation(reduceMotion ? nil : .interpolatingSpring(stiffness: 205, damping: 28), value: currentIndex)
    }

    private var currentFontSize: CGFloat {
        min(max(fontSize + 12, 34), 46)
    }

    private var supportFontSize: CGFloat {
        min(max(fontSize + 2, 22), 30)
    }

    private var displayLines: [SyncedLyricLine] {
        guard !lines.isEmpty else { return [] }
        let lower = max(0, currentIndex - 3)
        let upper = min(lines.count - 1, currentIndex + 4)
        return Array(lines[lower...upper])
    }

    private func relativeOffset(for line: SyncedLyricLine) -> Int {
        guard let index = lines.firstIndex(where: { $0.id == line.id }) else { return 0 }
        return index - currentIndex
    }

    private func yOffset(for offset: Int) -> CGFloat {
        switch offset {
        case -3: return -220
        case -2: return -150
        case -1: return -78
        case 0: return 0
        case 1: return 86
        case 2: return 156
        case 3: return 224
        case 4: return 286
        default: return CGFloat(offset) * 72
        }
    }

    private func opacity(for offset: Int) -> Double {
        switch abs(offset) {
        case 0: return 1.0
        case 1: return 0.54
        case 2: return 0.30
        case 3: return 0.14
        default: return 0.06
        }
    }
}
