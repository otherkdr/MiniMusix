import SwiftUI

struct AlbumArtworkView: View {
    var track: NowPlayingTrack
    var size: CGFloat
    var glow: Bool

    var body: some View {
        ZStack {
            if let artwork = track.artwork {
                Image(nsImage: artwork)
                    .resizable()
                    .scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: size * 0.22, style: .continuous))
            } else {
                RoundedRectangle(cornerRadius: size * 0.22, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [track.dominantColor, track.secondaryColor],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                Image(systemName: track.artworkSystemName)
                    .font(.system(size: size * 0.34, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)
                    .foregroundStyle(.white)
            }
        }
        .frame(width: size, height: size)
        .shadow(color: glow ? track.dominantColor.opacity(0.28) : .clear, radius: 16, y: 7)
        .accessibilityLabel("\(track.identity.album) artwork")
    }
}

struct ProgressStrip: View {
    var track: NowPlayingTrack
    var height: CGFloat = 4
    var seek: ((TimeInterval) -> Void)?

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(.secondary.opacity(0.16))
                Capsule()
                    .fill(
                        LinearGradient(
                            colors: [track.dominantColor, track.secondaryColor],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(width: proxy.size.width * track.progress)
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onEnded { value in
                        guard track.identity.duration > 0 else { return }
                        let ratio = min(max(value.location.x / max(proxy.size.width, 1), 0), 1)
                        seek?(track.identity.duration * ratio)
                    }
            )
        }
        .frame(height: height)
    }
}

struct TrackTimeRow: View {
    var track: NowPlayingTrack

    var body: some View {
        HStack {
            Text(Self.format(track.elapsed))
            Spacer()
            Text(track.identity.duration > 0 ? Self.format(track.identity.duration) : "--:--")
        }
        .font(.caption2.monospacedDigit())
        .foregroundStyle(.secondary)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("Elapsed \(Self.format(track.elapsed)) of \(track.identity.duration > 0 ? Self.format(track.identity.duration) : "unknown duration")")
    }

    static func format(_ value: TimeInterval) -> String {
        guard value.isFinite, value >= 0 else { return "0:00" }
        let total = Int(value.rounded(.down))
        let minutes = total / 60
        let seconds = total % 60
        return "\(minutes):\(String(format: "%02d", seconds))"
    }
}

struct GlassIconButton: View {
    var systemName: String
    var label: String
    var tint: Color
    var size: CGFloat = 40
    var isProminent = false
    var symbolEffectActive = false
    var action: () -> Void

    @State private var isHovered = false

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: isProminent ? 18 : 15, weight: isProminent ? .bold : .semibold))
                .symbolRenderingMode(.hierarchical)
                .foregroundStyle(.primary)
                .frame(width: size, height: size)
                .contentTransition(.symbolEffect(.replace))
                .symbolEffect(.bounce, value: symbolEffectActive)
        }
        .buttonStyle(.plain)
        .glassEffect(.regular.tint(tint.opacity(isHovered ? 0.16 : 0.07)).interactive(), in: Circle())
        .overlay {
            Circle()
                .strokeBorder(.white.opacity(isHovered ? 0.28 : 0.13), lineWidth: 0.8)
        }
        .shadow(color: tint.opacity(isHovered ? 0.10 : 0.035), radius: isHovered ? 8 : 3, y: isHovered ? 4 : 2)
        .scaleEffect(isHovered ? 1.055 : 1)
        .animation(.spring(response: 0.24, dampingFraction: 0.72), value: isHovered)
        .onHover { isHovered = $0 }
        .contentShape(Circle())
        .help(label)
        .accessibilityLabel(label)
    }
}

struct TransportControls: View {
    @ObservedObject var store: NowPlayingStore
    var prominent = false

    var body: some View {
        let isPlaying = store.currentTrack?.playbackState == .playing
        HStack(spacing: prominent ? 11 : 7) {
            GlassIconButton(
                systemName: "backward.fill",
                label: "Previous",
                tint: store.currentTrack?.secondaryColor ?? .secondary,
                size: prominent ? 42 : 34
            ) {
                store.skipBack()
            }

            GlassIconButton(
                systemName: isPlaying ? "pause.fill" : "play.fill",
                label: isPlaying ? "Pause" : "Play",
                tint: store.currentTrack?.dominantColor ?? .secondary,
                size: prominent ? 50 : 42,
                isProminent: true,
                symbolEffectActive: isPlaying
            ) {
                store.togglePlayback()
            }

            GlassIconButton(
                systemName: "forward.fill",
                label: "Next",
                tint: store.currentTrack?.secondaryColor ?? .secondary,
                size: prominent ? 42 : 34
            ) {
                store.skipForward()
            }
        }
    }
}

struct SideGlassButton: View {
    var systemName: String
    var label: String
    var tint: Color
    var action: () -> Void
    @State private var isHovered = false

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 17, weight: .semibold))
                .frame(width: 48, height: 48)
        }
        .buttonStyle(.plain)
        .foregroundStyle(.primary)
        .glassEffect(.regular.tint(tint.opacity(isHovered ? 0.13 : 0.055)).interactive(), in: Circle())
        .overlay {
            Circle()
                .strokeBorder(.white.opacity(isHovered ? 0.3 : 0.14), lineWidth: 0.8)
        }
        .shadow(color: tint.opacity(isHovered ? 0.16 : 0.05), radius: isHovered ? 12 : 5, y: isHovered ? 6 : 3)
        .scaleEffect(isHovered ? 1.06 : 1)
        .animation(.spring(response: 0.25, dampingFraction: 0.72), value: isHovered)
        .onHover { isHovered = $0 }
        .contentShape(Circle())
        .help(label)
        .accessibilityLabel(label)
    }
}

struct TrackTextStack: View {
    var track: NowPlayingTrack
    var compact: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: compact ? 2 : 5) {
            Text(track.identity.title)
                .font(compact ? .headline : .title3.weight(.semibold))
                .lineLimit(1)
                .contentTransition(.numericText())
            Text(track.identity.artist)
                .font(compact ? .caption : .callout)
                .foregroundStyle(.secondary)
                .lineLimit(1)
            if !compact {
                Text("\(track.identity.album) • \(track.source.rawValue)")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }
        }
    }
}

struct MiniPlayerPill: View {
    @ObservedObject var store: NowPlayingStore
    var mode: MiniPlayerMode
    var namespace: Namespace.ID?
    var artworkAction: (() -> Void)?
    @State private var isHovered = false

    var body: some View {
        if let track = store.currentTrack {
            activePill(track)
        } else {
            idlePill
        }
    }

    private func activePill(_ track: NowPlayingTrack) -> some View {
        HStack(spacing: mode == .compact ? 12 : 18) {
            artwork(track)

            VStack(alignment: .leading, spacing: mode == .compact ? 8 : 14) {
                TrackTextStack(track: track, compact: mode == .compact)
                VStack(spacing: mode == .compact ? 4 : 6) {
                    ProgressStrip(track: track, height: mode == .compact ? 3 : 5) { seconds in
                        store.seek(to: seconds)
                    }
                    TrackTimeRow(track: track)
                }
            }
            .frame(width: mode == .compact ? 178 : 270, alignment: .leading)

            TransportControls(store: store, prominent: mode != .compact)
        }
        .modifier(PillChrome(store: store, tint: track.dominantColor, secondaryTint: track.secondaryColor, isHovered: $isHovered, mode: mode))
    }

    @ViewBuilder
    private func artwork(_ track: NowPlayingTrack) -> some View {
        let artwork = AlbumArtworkView(track: track, size: mode == .compact ? 60 : 98, glow: store.settings.artworkGlow)

        if let artworkAction {
            Button(action: artworkAction) {
                matchedArtwork(artwork)
            }
            .buttonStyle(.plain)
            .contentShape(RoundedRectangle(cornerRadius: (mode == .compact ? 60 : 98) * 0.22, style: .continuous))
            .help("Open Lockscreen Player")
        } else {
            matchedArtwork(artwork)
        }
    }

    @ViewBuilder
    private func matchedArtwork<Content: View>(_ content: Content) -> some View {
        if let namespace {
            content.matchedGeometryEffect(id: "lockscreenArtwork", in: namespace)
        } else {
            content
        }
    }

    private var idlePill: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 15, style: .continuous)
                    .fill(.white.opacity(0.08))
                Image(systemName: "music.note")
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .frame(width: 54, height: 54)

            VStack(alignment: .leading, spacing: 4) {
                Text("Not Playing")
                    .font(.headline)
                Text("Waiting for media")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(width: 180, alignment: .leading)

            GlassIconButton(systemName: "arrow.clockwise", label: "Refresh Playback", tint: .secondary, size: 40) {
                Task { await store.refreshMetadata() }
            }
        }
        .modifier(PillChrome(store: store, tint: .secondary, secondaryTint: Color(nsColor: .tertiaryLabelColor), isHovered: $isHovered, mode: .compact))
    }
}

private struct PillChrome: ViewModifier {
    @ObservedObject var store: NowPlayingStore
    var tint: Color
    var secondaryTint: Color
    @Binding var isHovered: Bool
    var mode: MiniPlayerMode

    func body(content: Content) -> some View {
        content
            .padding(mode == .compact ? 10 : 16)
        .glassEffect(
            .regular.tint(tint.opacity(store.settings.albumTintStrength)).interactive(),
            in: RoundedRectangle(cornerRadius: store.settings.cornerRadius, style: .continuous)
        )
        .overlay {
            RoundedRectangle(cornerRadius: store.settings.cornerRadius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            .white.opacity(isHovered ? 0.13 : 0.07),
                            secondaryTint.opacity(store.settings.albumTintStrength * 0.42),
                            .clear
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .allowsHitTesting(false)
        }
        .overlay {
            RoundedRectangle(cornerRadius: store.settings.cornerRadius, style: .continuous)
                .strokeBorder(.white.opacity(isHovered ? 0.28 : 0.15), lineWidth: 0.8)
                .allowsHitTesting(false)
        }
        .shadow(color: tint.opacity(isHovered ? 0.13 : 0.06), radius: isHovered ? 18 : 10, y: isHovered ? 9 : 5)
        .scaleEffect(isHovered ? 1.012 : 1)
        .onHover { isHovered = $0 }
        .animation(.spring(response: 0.45, dampingFraction: 0.82), value: mode)
        .animation(.spring(response: 0.28, dampingFraction: 0.78), value: isHovered)
    }
}

struct MiniMusixLogo: View {
    var size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color(red: 0.38, green: 0.43, blue: 0.34),
                            Color(red: 0.72, green: 0.58, blue: 0.38)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            Image(systemName: "waveform")
                .font(.system(size: size * 0.42, weight: .bold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .overlay {
            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .strokeBorder(.white.opacity(0.28), lineWidth: 0.8)
        }
        .shadow(color: .black.opacity(0.12), radius: 16, y: 8)
    }
}
