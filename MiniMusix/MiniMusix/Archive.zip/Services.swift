import Foundation
import Combine
import SwiftUI
import AppKit
import MediaRemoteAdapter

protocol PlaybackProvider {
    var source: PlaybackSource { get }
    func currentTrack() async -> NowPlayingTrack?
}

final class ArtworkCache {
    private var colorsByTrack: [TrackIdentity: (Color, Color)] = [:]

    func colors(for track: NowPlayingTrack) -> (Color, Color) {
        if let cached = colorsByTrack[track.identity] {
            return cached
        }
        let colors = (track.dominantColor, track.secondaryColor)
        colorsByTrack[track.identity] = colors
        return colors
    }

    func clear() {
        colorsByTrack.removeAll()
    }
}

final class ArtworkAnalyzer {
    func colors(from image: NSImage?) -> (Color, Color) {
        guard let image,
              let cgImage = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            return (
                Color(red: 0.43, green: 0.49, blue: 0.39),
                Color(red: 0.70, green: 0.55, blue: 0.35)
            )
        }

        let width = 1
        let height = 1
        var pixel = [UInt8](repeating: 0, count: 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let context = CGContext(
            data: &pixel,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else {
            return (.secondary, Color(nsColor: .tertiaryLabelColor))
        }

        context.interpolationQuality = .medium
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        let red = Double(pixel[0]) / 255
        let green = Double(pixel[1]) / 255
        let blue = Double(pixel[2]) / 255
        let dominant = Color(red: red, green: green, blue: blue)
        let secondary = Color(
            red: min(red * 1.18 + 0.08, 1),
            green: min(green * 1.12 + 0.08, 1),
            blue: min(blue * 1.08 + 0.08, 1)
        )
        return (dominant, secondary)
    }
}

final class MediaRemotePlaybackProvider: PlaybackProvider {
    let source: PlaybackSource = .mediaRemote

    private let controller = MediaController()
    private let artworkAnalyzer = ArtworkAnalyzer()
    private var latestTrack: NowPlayingTrack?

    var onTrackChanged: ((NowPlayingTrack?) -> Void)?
    var onPermissionChanged: ((BackendPermissionState) -> Void)?

    init() {
        controller.onTrackInfoReceived = { [weak self] trackInfo in
            guard let self else { return }
            let track = trackInfo.flatMap(self.makeTrack(from:))
            self.latestTrack = track
            self.onPermissionChanged?(.ready)
            self.onTrackChanged?(track)
        }
        controller.onListenerTerminated = { [weak self] in
            self?.onPermissionChanged?(.unavailable("MediaRemote listener stopped. Refresh playback to restart it."))
        }
        controller.onDecodingError = { [weak self] error, _ in
            self?.onPermissionChanged?(.unavailable("MediaRemote returned unreadable metadata: \(error.localizedDescription)"))
        }
    }

    func startListening() {
        controller.startListening()
        controller.getTrackInfo { [weak self] trackInfo in
            guard let self else { return }
            let track = trackInfo.flatMap(self.makeTrack(from:))
            self.latestTrack = track
            self.onPermissionChanged?(.ready)
            self.onTrackChanged?(track)
        }
    }

    func stopListening() {
        controller.stopListening()
    }

    func currentTrack() async -> NowPlayingTrack? {
        if let latestTrack {
            return latestTrack
        }

        return await withCheckedContinuation { continuation in
            controller.getTrackInfo { [weak self] trackInfo in
                let track = trackInfo.flatMap { self?.makeTrack(from: $0) }
                self?.latestTrack = track
                continuation.resume(returning: track)
            }
        }
    }

    func play() {
        if isMusic(bundleIdentifier: latestTrack?.bundleIdentifier) { musicPlay() ; return }
        if isSpotify(bundleIdentifier: latestTrack?.bundleIdentifier) { spotifyPlay() ; return }
        controller.play()
    }

    func pause() {
        if isMusic(bundleIdentifier: latestTrack?.bundleIdentifier) { musicPause() ; return }
        if isSpotify(bundleIdentifier: latestTrack?.bundleIdentifier) { spotifyPause() ; return }
        controller.pause()
    }

    func togglePlayPause() {
        if isMusic(bundleIdentifier: latestTrack?.bundleIdentifier) { musicPlayPause() ; return }
        if isSpotify(bundleIdentifier: latestTrack?.bundleIdentifier) { spotifyPlayPause() ; return }
        controller.togglePlayPause()
    }

    func nextTrack() {
        if isMusic(bundleIdentifier: latestTrack?.bundleIdentifier) { musicNextTrack() ; return }
        if isSpotify(bundleIdentifier: latestTrack?.bundleIdentifier) { spotifyNextTrack() ; return }
        controller.nextTrack()
    }

    func previousTrack() {
        if isMusic(bundleIdentifier: latestTrack?.bundleIdentifier) { musicPreviousTrack() ; return }
        if isSpotify(bundleIdentifier: latestTrack?.bundleIdentifier) { spotifyPreviousTrack() ; return }
        controller.previousTrack()
    }

    func seek(to seconds: TimeInterval) {
        controller.setTime(seconds: seconds)
    }

    /// Attempts a minimal Apple Events operation to encourage macOS to show the
    /// Automation permission prompt, if needed. Safe to call multiple times.
    func requestAutomationPermission() {
        // Strategy:
        // 1) Try a harmless metadata fetch to exercise the Automation path.
        // 2) If available, attempt a no-op Apple Event to the Music app via NSAppleScript.
        //    This is wrapped defensively so it won't crash on failure.

        controller.getTrackInfo { [weak self] _ in
            // Receiving a callback here should already exercise the underlying mechanism.
            // If permissions are missing, the system may prompt the user.
            // We don't need to do anything with the result.
            _ = self // keep capture
        }

        // Best-effort: send a benign Apple Event to Music to nudge the prompt.
        // This will do nothing if Music isn't installed or Apple Events are blocked.
        #if canImport(AppKit)
        let scriptSource = "tell application \"Music\" to get running"
        if let script = NSAppleScript(source: scriptSource) {
            var errorDict: NSDictionary?
            _ = script.executeAndReturnError(&errorDict)
            // We intentionally ignore errors; the goal is simply to trigger the permission flow.
        }
        #endif
    }

    // MARK: - App-specific control via AppleScript (Music / Spotify)
    private func runAppleScript(_ source: String) {
        #if canImport(AppKit)
        guard let script = NSAppleScript(source: source) else { return }
        var error: NSDictionary?
        _ = script.executeAndReturnError(&error)
        #endif
    }

    private func isMusic(bundleIdentifier: String?) -> Bool {
        bundleIdentifier == "com.apple.Music"
    }

    private func isSpotify(bundleIdentifier: String?) -> Bool {
        bundleIdentifier == "com.spotify.client"
    }

    // Playback controls
    private func musicPlayPause() {
        runAppleScript("tell application \"Music\" to playpause")
    }
    private func musicPlay() {
        runAppleScript("tell application \"Music\" to play")
    }
    private func musicPause() {
        runAppleScript("tell application \"Music\" to pause")
    }
    private func musicNextTrack() {
        runAppleScript("tell application \"Music\" to next track")
    }
    private func musicPreviousTrack() {
        runAppleScript("tell application \"Music\" to previous track")
    }

    private func spotifyPlayPause() {
        runAppleScript("tell application \"Spotify\" to playpause")
    }
    private func spotifyPlay() {
        runAppleScript("tell application \"Spotify\" to play")
    }
    private func spotifyPause() {
        runAppleScript("tell application \"Spotify\" to pause")
    }
    private func spotifyNextTrack() {
        runAppleScript("tell application \"Spotify\" to next track")
    }
    private func spotifyPreviousTrack() {
        runAppleScript("tell application \"Spotify\" to previous track")
    }

    // Queue operations (best-effort)
    // Music: add a URL (Apple Music link or file) to the end of the queue if possible.
    func addToQueueMusic(urlString: String) {
        // Best-effort: Music's AppleScript dictionary doesn't expose a direct queue API.
        // This attempts to add a local file path to the Library as a fallback.
        // If you intend to add Apple Music URLs, additional logic is required.
        let escaped = urlString.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
        let script = "tell application \"Music\" to try\nadd POSIX file \"\(escaped)\"\nend try"
        runAppleScript(script)
    }

    // Spotify: add a track/URI to the queue (requires Spotify 1.1.56+). Fallback: play track.
    func addToQueueSpotify(uri: String) {
        let escaped = uri.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"")
        let queueScript = "tell application \"Spotify\" to add track \"\(escaped)\" to queue"
        runAppleScript(queueScript)
    }

    func supportsNativeQueueManagement() -> Bool {
        guard let bundleIdentifier = latestTrack?.bundleIdentifier else { return false }
        return bundleIdentifier == "com.apple.Music" || bundleIdentifier == "com.spotify.client"
    }

    func queueCurrentTrack() {
        guard let track = latestTrack else { return }

        if track.bundleIdentifier == "com.spotify.client" {
            let title = track.identity.title.replacingOccurrences(of: "\"", with: "")
            let artist = track.identity.artist.replacingOccurrences(of: "\"", with: "")
            let script = "tell application \"Spotify\" to search \"\(title) \(artist)\""
            runAppleScript(script)
            return
        }

        if track.bundleIdentifier == "com.apple.Music" {
            let title = track.identity.title.replacingOccurrences(of: "\"", with: "")
            let script = "tell application \"Music\" to search library playlist 1 for \"\(title)\""
            runAppleScript(script)
        }
    }

    private func makeTrack(from info: TrackInfo) -> NowPlayingTrack? {
        let payload = info.payload
        let title = payload.title?.trimmingCharacters(in: .whitespacesAndNewlines)
        let artist = payload.artist?.trimmingCharacters(in: .whitespacesAndNewlines)

        guard let title, !title.isEmpty,
              let artist, !artist.isEmpty else {
            return nil
        }

        let album = payload.album?.trimmingCharacters(in: .whitespacesAndNewlines)
        let duration = max((payload.durationMicros ?? 0) / 1_000_000, 0)
        let elapsed = max(payload.currentElapsedTime ?? ((payload.elapsedTimeMicros ?? 0) / 1_000_000), 0)
        let artwork = payload.artwork
        let colors = artworkAnalyzer.colors(from: artwork)

        return NowPlayingTrack(
            identity: TrackIdentity(
                title: title,
                artist: artist,
                album: album?.isEmpty == false ? album! : "Unknown Album",
                duration: duration
            ),
            artworkSystemName: "music.note",
            artwork: artwork,
            dominantColor: colors.0,
            secondaryColor: colors.1,
            elapsed: duration > 0 ? min(elapsed, duration) : elapsed,
            playbackState: payload.isPlaying == true ? .playing : .paused,
            source: source(for: payload.bundleIdentifier),
            applicationName: payload.applicationName,
            bundleIdentifier: payload.bundleIdentifier
        )
    }

    private func source(for bundleIdentifier: String?) -> PlaybackSource {
        switch bundleIdentifier {
        case "com.apple.Music":
            return .appleMusic
        case "com.spotify.client":
            return .spotify
        default:
            return .mediaRemote
        }
    }
}

final class LyricsCache {
    private var storage: [TrackIdentity: LyricsPayload] = [:]

    subscript(identity: TrackIdentity) -> LyricsPayload? {
        get { storage[identity] }
        set { storage[identity] = newValue }
    }

    func clear() {
        storage.removeAll()
    }
}

struct LRCLIBResponse: Decodable {
    let id: Int?
    let trackName: String?
    let artistName: String?
    let albumName: String?
    let duration: Double?
    let instrumental: Bool?
    let syncedLyrics: String?
    let plainLyrics: String?
}

final class LyricsService {
    private let cache: LyricsCache
    private let session: URLSession
    private let userAgent = "MiniMusix/1.0 (https://github.com/keder/minimusix)"

    init(cache: LyricsCache = LyricsCache(), session: URLSession? = nil) {
        self.cache = cache

        if let session {
            self.session = session
        } else {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.timeoutIntervalForRequest = 20
            configuration.timeoutIntervalForResource = 30
            configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
            configuration.waitsForConnectivity = true
            configuration.httpMaximumConnectionsPerHost = 2
            self.session = URLSession(configuration: configuration)
        }
    }

    func lyrics(for track: NowPlayingTrack, settings: MiniMusixSettings) async -> LyricsPayload {
        if let cached = cache[track.identity] {
            return selectLyrics(cached, settings: settings)
        }

        guard settings.enableLRCLIB else {
            return .unavailable
        }

        guard !Task.isCancelled else {
            return .unavailable
        }

        let payload: LyricsPayload = await withTaskGroup(of: LyricsPayload?.self) { group in
            group.addTask { await self.fetchSignatureLyrics(for: track, cachedOnly: true) }
            group.addTask { await self.fetchSignatureLyrics(for: track, cachedOnly: false) }
            group.addTask { await self.fetchSearchLyrics(for: track) }

            for await result in group {
                if let result {
                    group.cancelAll()
                    return result
                }
            }

            return .unavailable
        }

        guard !Task.isCancelled else {
            return .unavailable
        }

        cache[track.identity] = payload
        return selectLyrics(payload, settings: settings)
    }

    private func fetchSignatureLyrics(for track: NowPlayingTrack, cachedOnly: Bool) async -> LyricsPayload? {
        let endpoint = cachedOnly ? "https://lrclib.net/api/get-cached" : "https://lrclib.net/api/get"
        guard var components = URLComponents(string: endpoint) else {
            return nil
        }

        let title = cleanedMetadata(track.identity.title)
        let artist = cleanedMetadata(track.identity.artist)
        let album = cleanedMetadata(track.identity.album)
        let duration = Int(track.identity.duration.rounded())

        guard !title.isEmpty, !artist.isEmpty, !album.isEmpty, duration > 0 else {
            return nil
        }

        components.queryItems = [
            URLQueryItem(name: "track_name", value: title),
            URLQueryItem(name: "artist_name", value: artist),
            URLQueryItem(name: "album_name", value: album),
            URLQueryItem(name: "duration", value: String(duration))
        ]

        guard let url = components.url else {
            return nil
        }

        guard !Task.isCancelled else {
            return nil
        }
        do {
            let (data, response) = try await session.data(for: request(for: url))
            guard let httpResponse = response as? HTTPURLResponse else {
                return nil
            }

            switch httpResponse.statusCode {
            case 200:
                let decoded = try JSONDecoder().decode(LRCLIBResponse.self, from: data)
                return makePayload(from: decoded)
            case 404:
                return nil
            default:
                return nil
            }
        } catch {
            return nil
        }
    }

    private func fetchSearchLyrics(for track: NowPlayingTrack) async -> LyricsPayload? {
        guard var components = URLComponents(string: "https://lrclib.net/api/search") else {
            return nil
        }

        let title = cleanedMetadata(track.identity.title)
        let artist = cleanedMetadata(track.identity.artist)
        let album = cleanedMetadata(track.identity.album)

        guard !title.isEmpty else {
            return nil
        }

        components.queryItems = [
            URLQueryItem(name: "track_name", value: title),
            URLQueryItem(name: "artist_name", value: artist.isEmpty ? nil : artist),
            URLQueryItem(name: "album_name", value: album.isEmpty ? nil : album)
        ].filter { $0.value != nil }

        guard let url = components.url else {
            return nil
        }

        guard !Task.isCancelled else {
            return nil
        }
        do {
            let (data, response) = try await session.data(for: request(for: url))
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                return nil
            }

            let decoded = try JSONDecoder().decode([LRCLIBResponse].self, from: data)
            guard let bestMatch = decoded
                .filter({ isAcceptableMatch($0, for: track) })
                .sorted(by: { score($0, for: track) > score($1, for: track) })
                .first else {
                return nil
            }

            if let id = bestMatch.id,
               let exactPayload = await fetchLyricsByID(id) {
                return exactPayload
            }

            return makePayload(from: bestMatch)
        } catch {
            return nil
        }
    }

    private func fetchLyricsByID(_ id: Int) async -> LyricsPayload? {
        guard let url = URL(string: "https://lrclib.net/api/get/\(id)") else {
            return nil
        }

        guard !Task.isCancelled else {
            return nil
        }
        do {
            let (data, response) = try await session.data(for: request(for: url))
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                return nil
            }

            let decoded = try JSONDecoder().decode(LRCLIBResponse.self, from: data)
            return makePayload(from: decoded)
        } catch {
            return nil
        }
    }

    private func request(for url: URL) -> URLRequest {
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue(userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("close", forHTTPHeaderField: "Connection")
        request.cachePolicy = .reloadIgnoringLocalCacheData
        return request
    }

    private func parseSyncedLyrics(_ text: String) -> [SyncedLyricLine] {
        let timestampPattern = #"\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]"#
        guard let regex = try? NSRegularExpression(pattern: timestampPattern) else {
            return []
        }

        var parsedLines: [SyncedLyricLine] = []
        let rows = text.components(separatedBy: .newlines)

        for row in rows {
            let range = NSRange(row.startIndex..<row.endIndex, in: row)
            let matches = regex.matches(in: row, range: range)
            guard !matches.isEmpty else { continue }

            let lyricStartIndex: String.Index
            if let lastMatch = matches.last,
               let lastRange = Range(lastMatch.range, in: row) {
                lyricStartIndex = lastRange.upperBound
            } else {
                continue
            }

            let lyric = row[lyricStartIndex...]
                .trimmingCharacters(in: .whitespacesAndNewlines)

            guard !lyric.isEmpty else { continue }

            for match in matches {
                guard let minutesRange = Range(match.range(at: 1), in: row),
                      let secondsRange = Range(match.range(at: 2), in: row),
                      let minutes = Double(row[minutesRange]),
                      let seconds = Double(row[secondsRange]) else {
                    continue
                }

                var fractionalSeconds = 0.0
                if match.range(at: 3).location != NSNotFound,
                   let fractionRange = Range(match.range(at: 3), in: row) {
                    let fractionText = String(row[fractionRange])
                    if let fraction = Double(fractionText) {
                        fractionalSeconds = fraction / pow(10, Double(fractionText.count))
                    }
                }

                parsedLines.append(
                    SyncedLyricLine(
                        time: minutes * 60 + seconds + fractionalSeconds,
                        text: lyric
                    )
                )
            }
        }

        return parsedLines.sorted { $0.time < $1.time }
    }

    private func makePayload(from response: LRCLIBResponse) -> LyricsPayload? {
        if response.instrumental == true {
            return .plain("")
        }

        if let synced = response.syncedLyrics?.trimmingCharacters(in: .whitespacesAndNewlines),
           !synced.isEmpty {
            let lines = parseSyncedLyrics(synced)
            let usableLines = lines.filter { !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            if !usableLines.isEmpty {
                return .synced(usableLines)
            }
        }

        if let plain = response.plainLyrics?.trimmingCharacters(in: .whitespacesAndNewlines),
           !plain.isEmpty {
            return .plain(plain)
        }

        if response.instrumental == true {
            return .plain("")
        }

        return nil
    }

    private func selectLyrics(_ payload: LyricsPayload, settings: MiniMusixSettings) -> LyricsPayload {
        switch payload {
        case .loading:
            return .loading
        case .synced(let lines):
            if settings.syncedLyrics {
                return .synced(lines)
            }
            if settings.plainLyrics {
                return .plain(lines.map(\.text).joined(separator: "\n"))
            }
            return .unavailable
        case .plain(let text):
            return settings.plainLyrics ? .plain(text) : .unavailable
        case .unavailable:
            return .unavailable
        }
    }

    private func score(_ response: LRCLIBResponse, for track: NowPlayingTrack) -> Double {
        var score = 0.0
        if normalized(response.trackName) == normalized(track.identity.title) {
            score += 5
        }
        if normalized(response.artistName) == normalized(track.identity.artist) {
            score += 4
        }
        if normalized(response.albumName) == normalized(track.identity.album) {
            score += 2
        }
        if let duration = response.duration, track.identity.duration > 0 {
            let difference = abs(duration - track.identity.duration)
            if difference <= 2 {
                score += 4
            } else if difference <= 8 {
                score += max(0, 2 - difference / 8)
            }
        }
        if response.syncedLyrics?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            score += 1
        }
        if response.plainLyrics?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false {
            score += 0.5
        }
        return score
    }

    private func isAcceptableMatch(_ response: LRCLIBResponse, for track: NowPlayingTrack) -> Bool {
        let responseTitle = normalized(response.trackName)
        let trackTitle = normalized(track.identity.title)
        let responseArtist = normalized(response.artistName)
        let trackArtist = normalized(track.identity.artist)

        let titleMatches = responseTitle == trackTitle
        let artistMatches = !responseArtist.isEmpty
            && !trackArtist.isEmpty
            && (responseArtist.contains(trackArtist) || trackArtist.contains(responseArtist))

        guard titleMatches, artistMatches else {
            return false
        }

        guard let duration = response.duration, track.identity.duration > 0 else {
            return true
        }

        return abs(duration - track.identity.duration) <= 8
    }

    private func cleanedMetadata(_ value: String?) -> String {
        let cleaned = value?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\u{00A0}", with: " ") ?? ""

        if cleaned.caseInsensitiveCompare("Unknown Album") == .orderedSame {
            return ""
        }

        return cleaned
    }

    private func normalized(_ value: String?) -> String {
        normalized(value ?? "")
    }

    private func normalized(_ value: String) -> String {
        value
            .lowercased()
            .replacingOccurrences(of: #"\s*\([^)]*\)"#, with: "", options: .regularExpression)
            .replacingOccurrences(of: #"\s*\[[^\]]*\]"#, with: "", options: .regularExpression)
            .replacingOccurrences(of: #"[^a-z0-9]+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

@MainActor
final class NowPlayingStore: ObservableObject {
    @Published var currentTrack: NowPlayingTrack?
    @Published var queue: [QueueItem]
    @Published var lyrics: LyricsPayload = .unavailable
    @Published var settings = MiniMusixSettings()
    @Published var isPlaybackAvailable = false

    private let providers: [PlaybackProvider]
    private let mediaRemoteProvider: MediaRemotePlaybackProvider
    private let artworkCache = ArtworkCache()
    private let lyricsService: LyricsService
    private var lastValidTrack: NowPlayingTrack?
    private var lyricsTargetIdentity: TrackIdentity?
    private var lyricsTask: Task<Void, Never>?
    private var playbackTickTask: Task<Void, Never>?

    init(
        providers: [PlaybackProvider]? = nil,
        lyricsService: LyricsService? = nil
    ) {
        let mediaRemoteProvider = MediaRemotePlaybackProvider()
        self.mediaRemoteProvider = mediaRemoteProvider
        self.providers = providers ?? [mediaRemoteProvider]
        self.lyricsService = lyricsService ?? LyricsService()
        self.currentTrack = nil
        self.queue = []
        self.lastValidTrack = nil

        mediaRemoteProvider.onTrackChanged = { [weak self] track in
            Task { @MainActor in
                self?.apply(track)
            }
        }
        mediaRemoteProvider.onPermissionChanged = { [weak self] state in
            Task { @MainActor in
                self?.settings.mediaRemotePermission = state
            }
        }
        mediaRemoteProvider.startListening()
        startPlaybackTicker()
    }

    deinit {
        lyricsTask?.cancel()
        playbackTickTask?.cancel()
        mediaRemoteProvider.stopListening()
    }

    private func startPlaybackTicker() {
        playbackTickTask?.cancel()
        playbackTickTask = Task { [weak self] in
            var lastTickDate = Date()

            while !Task.isCancelled {
                try? await Task.sleep(for: .milliseconds(250))
                guard !Task.isCancelled else { break }

                let now = Date()
                let delta = now.timeIntervalSince(lastTickDate)
                lastTickDate = now

                await MainActor.run {
                    self?.tick(delta: delta)
                }
            }
        }
    }

    func refreshMetadata() async {
        for provider in providers {
            if let track = await provider.currentTrack() {
                guard accepts(track) else {
                    apply(nil)
                    return
                }
                apply(track)
                return
            }
        }

        apply(nil)
    }

    private func accepts(_ track: NowPlayingTrack) -> Bool {
        settings.source == .automatic || settings.source == track.source || settings.source == .mediaRemote
    }

    private func apply(_ incomingTrack: NowPlayingTrack?) {
        guard var track = incomingTrack else {
            currentTrack = nil
            isPlaybackAvailable = false
            lyrics = .unavailable
            lyricsTargetIdentity = nil
            lyricsTask?.cancel()
            return
        }

        guard accepts(track) else {
            currentTrack = nil
            isPlaybackAvailable = false
            lyrics = .unavailable
            lyricsTargetIdentity = nil
            lyricsTask?.cancel()
            return
        }

        isPlaybackAvailable = true
        if track.artwork == nil {
            if let lastValidTrack, lastValidTrack.identity == track.identity {
                track.artwork = lastValidTrack.artwork
                track.dominantColor = lastValidTrack.dominantColor
                track.secondaryColor = lastValidTrack.secondaryColor
            } else {
                let colors = artworkCache.colors(for: track)
                track.dominantColor = colors.0
                track.secondaryColor = colors.1
            }
        }

        currentTrack = track
        lastValidTrack = track

        let shouldLoadLyrics = lyricsTargetIdentity.map { !sameLyricsTarget($0, track.identity) } ?? true
        if shouldLoadLyrics {
            lyricsTargetIdentity = track.identity
            lyrics = settings.enableLRCLIB ? .loading : .unavailable
            loadLyrics(for: track)
        }
    }

    func togglePlayback() {
        mediaRemoteProvider.togglePlayPause()
        if var track = currentTrack {
            track.playbackState = track.playbackState == .playing ? .paused : .playing
            currentTrack = track
        }
        Task {
            try? await Task.sleep(for: .milliseconds(180))
            await refreshMetadata()
        }
    }

    func skipForward() {
        mediaRemoteProvider.nextTrack()
        Task {
            try? await Task.sleep(for: .milliseconds(220))
            await refreshMetadata()
        }
    }

    func skipBack() {
        mediaRemoteProvider.previousTrack()
        Task {
            try? await Task.sleep(for: .milliseconds(220))
            await refreshMetadata()
        }
    }

    func seek(to seconds: TimeInterval) {
        mediaRemoteProvider.seek(to: seconds)
        if var track = currentTrack {
            track.elapsed = min(max(seconds, 0), track.identity.duration)
            currentTrack = track
        }
    }

    func playQueueItem(_ item: QueueItem) {
        guard let index = queue.firstIndex(where: { $0.id == item.id }) else { return }
        let selected = queue.remove(at: index)
        if let currentTrack {
            queue.insert(QueueItem(track: currentTrack), at: min(index, queue.count))
        }
        apply(selected.track)
    }

    func addCurrentTrackToQueue() {
        guard let currentTrack else { return }

        if mediaRemoteProvider.supportsNativeQueueManagement() {
            mediaRemoteProvider.queueCurrentTrack()
        }

        guard !queue.contains(where: { $0.track.identity == currentTrack.identity }) else { return }
        queue.append(QueueItem(track: currentTrack))
    }

    func removeFromQueue(_ item: QueueItem) {
        queue.removeAll { $0.id == item.id }
    }

    func moveQueueItems(from source: IndexSet, to destination: Int) {
        guard settings.dragReordering else { return }
        queue.move(fromOffsets: source, toOffset: destination)
    }

    func tick(delta: TimeInterval = 1) {
        guard var track = currentTrack, track.playbackState == .playing else { return }
        let safeDelta = max(0, min(delta, 1))
        track.elapsed = track.identity.duration > 0 ? min(track.identity.duration, track.elapsed + safeDelta) : track.elapsed + safeDelta
        currentTrack = track
    }

    func clearArtworkCache() {
        artworkCache.clear()
    }

    func reloadLyrics() {
        guard let currentTrack else { return }
        lyricsTargetIdentity = currentTrack.identity
        lyrics = settings.enableLRCLIB ? .loading : .unavailable
        loadLyrics(for: currentTrack)
    }
    private func sameLyricsTarget(_ lhs: TrackIdentity, _ rhs: TrackIdentity) -> Bool {
        let titleMatches = normalizedLyricsKey(lhs.title) == normalizedLyricsKey(rhs.title)
        let artistMatches = normalizedLyricsKey(lhs.artist) == normalizedLyricsKey(rhs.artist)
        let albumMatches = normalizedLyricsKey(lhs.album) == normalizedLyricsKey(rhs.album)

        return titleMatches && artistMatches && albumMatches
    }

    private func normalizedLyricsKey(_ value: String?) -> String {
        let cleaned = value?
            .lowercased()
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\u{00A0}", with: " ") ?? ""

        if cleaned == "unknown album" {
            return ""
        }

        return cleaned
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
    }
    
    func requestAutomationPermission() {
        mediaRemoteProvider.requestAutomationPermission()
    }

    func refreshPermissions() {
        requestAutomationPermission()

        if currentTrack != nil {
            settings.mediaRemotePermission = .ready
        }

        if settings.enableLRCLIB {
            settings.lyricsPermission = .ready
        }
    }

    private func loadLyrics(for track: NowPlayingTrack) {
        lyricsTask?.cancel()
        lyricsTask = Task { [lyricsService] in
            guard !Task.isCancelled else { return }
            let currentSettings = await MainActor.run { self.settings }
            let payload = await lyricsService.lyrics(for: track, settings: currentSettings)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                guard self.currentTrack?.identity == track.identity else { return }
                self.settings.lyricsPermission = payload == .unavailable ? .unavailable("No LRCLIB lyrics found for this track.") : .ready
                self.lyrics = payload
            }
        }
    }
}

