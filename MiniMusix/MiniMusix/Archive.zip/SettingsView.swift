import SwiftUI
import AppKit

enum SettingsSection: String, CaseIterable, Identifiable {
    case general = "General"
    case miniPlayer = "MiniPlayer"
    case lyrics = "Lyrics"
    case queue = "Queue"
    case appearance = "Appearance"
    case playback = "Playback"
    case advanced = "Advanced"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .general: "gearshape.fill"
        case .miniPlayer: "music.note.tv.fill"
        case .lyrics: "quote.bubble.fill"
        case .queue: "list.bullet.rectangle.fill"
        case .appearance: "paintpalette.fill"
        case .playback: "play.circle.fill"
        case .advanced: "slider.horizontal.3"
        }
    }
}

struct MiniMusixSettingsView: View {
    @ObservedObject var store: NowPlayingStore
    @State private var selection: SettingsSection = .general

    private let textColor = SettingsPalette.text
    private let secondaryText = SettingsPalette.secondaryText

    var body: some View {
        HStack(spacing: 0) {
            sidebar

            Divider().opacity(0.35)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 24) {
                    settingsHeader
                    settingsContent(for: selection)
                }
                .padding(.horizontal, 34)
                .padding(.vertical, 30)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .background(contentBackground)
        }
        .frame(width: 860, height: 620)
        .background(contentBackground)
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
    }

    private var accent: Color {
        store.currentTrack?.dominantColor ?? SettingsPalette.accent
    }

    private var contentBackground: some View {
        ZStack {
            Color(red: 0.93, green: 0.92, blue: 0.86)

            LinearGradient(
                colors: [
                    Color.white.opacity(0.40),
                    Color(red: 0.82, green: 0.83, blue: 0.76).opacity(0.22),
                    accent.opacity(0.10)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )

            DiagonalSettingsTexture()
                .opacity(0.18)
        }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack(spacing: 10) {
                Circle().fill(.red).frame(width: 13, height: 13)
                Circle().fill(.yellow).frame(width: 13, height: 13)
                Circle().fill(.secondary.opacity(0.45)).frame(width: 13, height: 13)
                Spacer()
                Button {
                    NSApp.keyWindow?.close()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(secondaryText)
                        .frame(width: 26, height: 26)
                        .background(.white.opacity(0.30), in: Circle())
                }
                .buttonStyle(.plain)
                .help("Close Settings")
            }
            .padding(.top, 4)

            SettingsSidebarGroup(title: "MiniMusix", sections: [.general, .miniPlayer, .lyrics], selection: $selection, accent: accent)
            SettingsSidebarGroup(title: "Player", sections: [.queue, .appearance, .playback], selection: $selection, accent: accent)
            SettingsSidebarGroup(title: "System", sections: [.advanced], selection: $selection, accent: accent)

            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(width: 250)
        .background(
            Color(red: 0.93, green: 0.92, blue: 0.86)
                .opacity(0.72)
        )
    }

    private var settingsHeader: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(accent.opacity(0.16))
                    .frame(width: 48, height: 48)
                    .glassEffect(.regular.tint(accent.opacity(0.12)), in: RoundedRectangle(cornerRadius: 16, style: .continuous))

                Image(systemName: selection.icon)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(textColor)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(selection.rawValue)
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(textColor)
                Text(sectionSubtitle)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(secondaryText)
            }
        }
    }

    private var sectionSubtitle: String {
        switch selection {
        case .general: "Choose how MiniMusix connects and behaves."
        case .miniPlayer: "Tune the floating player layout and feel."
        case .lyrics: "Configure LRCLIB lyrics and display preferences."
        case .queue: "Control the queue panel and row behavior."
        case .appearance: "Adjust glass, tinting, and motion."
        case .playback: "Refresh metadata and check playback services."
        case .advanced: "Cache, onboarding, and reset tools."
        }
    }

    @ViewBuilder
    private func settingsContent(for section: SettingsSection) -> some View {
        switch section {
        case .general:
            VStack(alignment: .leading, spacing: 22) {
                SettingsCard(title: "Music + Audio Source") {
                    HStack(spacing: 16) {
                        SourceTile(title: "Music", icon: "music.note", source: .appleMusic, selection: $store.settings.source)
                        SourceTile(title: "Spotify", icon: "music.note.list", source: .spotify, selection: $store.settings.source)
                        SourceTile(title: "Auto", icon: "sparkles", source: .automatic, selection: $store.settings.source)
                        SourceTile(title: "System", icon: "dot.radiowaves.left.and.right", source: .mediaRemote, selection: $store.settings.source)
                    }
                }

                SettingsCard(title: "App Behavior") {
                    SettingsToggleRow(icon: "lock.open.fill", title: "Launch at Login", subtitle: "Start MiniMusix automatically.", isOn: $store.settings.launchAtLogin)
                    SettingsToggleRow(icon: "pin.fill", title: "Always on Top", subtitle: "Keep the miniplayer above other windows.", isOn: $store.settings.alwaysOnTop)
                    SettingsToggleRow(icon: "eye.slash.fill", title: "Hide from Screen Capture", subtitle: "Keep MiniMusix out of screenshots where supported.", isOn: $store.settings.hideFromScreenCapture)
                    SettingsToggleRow(icon: "moon.fill", title: "Hide When Playback Stops", subtitle: "Collapse when nothing is playing.", isOn: $store.settings.hideWhenPlaybackStops)
                }
            }

        case .miniPlayer:
            VStack(alignment: .leading, spacing: 22) {
                SettingsCard(title: "Default Mode") {
                    HStack(spacing: 16) {
                        ForEach(MiniPlayerMode.allCases) { mode in
                            ModeTile(mode: mode, selection: $store.settings.preferredMode, accent: accent)
                        }
                    }
                }

                SettingsCard(title: "Shape + Feel") {
                    SettingsSliderRow(icon: "paintbrush.pointed.fill", title: "Album Tint Strength", value: $store.settings.albumTintStrength, range: 0...0.24)
                    SettingsToggleRow(icon: "sparkle", title: "Artwork Glow", subtitle: "Use a subtle glow based on artwork.", isOn: $store.settings.artworkGlow)
                    SettingsSliderRow(icon: "square.roundedbottom.fill", title: "Corner Radius", value: $store.settings.cornerRadius, range: 18...38)
                }

                SettingsCard(title: "Position") {
                    Picker("Position Behavior", selection: $store.settings.positionBehavior) {
                        Text("Bottom Center").tag("Bottom Center")
                        Text("Remember Last Position").tag("Remember Last Position")
                    }
                    .pickerStyle(.segmented)
                }
            }

        case .lyrics:
            SettingsCard(title: "Lyrics") {
                SettingsToggleRow(icon: "quote.bubble.fill", title: "Enable LRCLIB", subtitle: "Fetch lyrics when music changes.", isOn: $store.settings.enableLRCLIB)
                    .onChange(of: store.settings.enableLRCLIB) { _, _ in store.reloadLyrics() }
                SettingsToggleRow(icon: "text.line.first.and.arrowtriangle.forward", title: "Synced Lyrics", subtitle: "Prefer timed lyrics when available.", isOn: $store.settings.syncedLyrics)
                    .onChange(of: store.settings.syncedLyrics) { _, _ in store.reloadLyrics() }
                SettingsToggleRow(icon: "text.alignleft", title: "Plain Lyrics", subtitle: "Use regular lyrics as a fallback.", isOn: $store.settings.plainLyrics)
                    .onChange(of: store.settings.plainLyrics) { _, _ in store.reloadLyrics() }
                SettingsSliderRow(icon: "textformat.size", title: "Font Size", value: $store.settings.lyricFontSize, range: 15...28)
                TextField("Missing Lyrics Message", text: $store.settings.missingLyricsMessage)
                    .textFieldStyle(.roundedBorder)
            }

        case .queue:
            SettingsCard(title: "Queue") {
                SettingsToggleRow(icon: "sidebar.left", title: "Queue Button Enabled", subtitle: "Show the left queue button.", isOn: $store.settings.queueButtonEnabled)
                SettingsToggleRow(icon: "arrow.up.arrow.down", title: "Drag Reordering", subtitle: "Allow local queue rows to move.", isOn: $store.settings.dragReordering)
                SettingsToggleRow(icon: "rectangle.compress.vertical", title: "Compact Rows", subtitle: "Use smaller queue rows.", isOn: $store.settings.compactRows)
            }

        case .appearance:
            SettingsCard(title: "Appearance") {
                SettingsSliderRow(icon: "circle.lefthalf.filled", title: "Liquid Glass Intensity", value: $store.settings.glassIntensity, range: 0.25...1)
                SettingsToggleRow(icon: "paintpalette.fill", title: "System Accent", subtitle: "Use your macOS accent color.", isOn: $store.settings.systemAccent)
                SettingsToggleRow(icon: "record.circle", title: "Album Colors", subtitle: "Tint UI based on artwork.", isOn: $store.settings.albumColors)
                SettingsToggleRow(icon: "figure.walk.motion", title: "Reduce Motion Support", subtitle: "Respect motion accessibility settings.", isOn: $store.settings.reduceMotionSupport)
            }

        case .playback:
            SettingsCard(title: "Playback") {
                Button("Refresh Metadata") {
                    Task { await store.refreshMetadata() }
                }
                .buttonStyle(.borderedProminent)

                SettingsStatusRow(title: "MediaRemote", state: store.settings.mediaRemotePermission)
                SettingsStatusRow(title: "LRCLIB", state: store.settings.lyricsPermission)
                SettingsStaticRow(icon: "checkmark.shield.fill", title: "Validate State After Commands", subtitle: "Enabled")
                SettingsStaticRow(icon: "clock.arrow.circlepath", title: "Avoid Stale Track Information", subtitle: "Enabled")
            }

        case .advanced:
            SettingsCard(title: "Advanced") {
                Button("Clear Artwork Cache") { store.clearArtworkCache() }
                Button("Refresh Metadata") { Task { await store.refreshMetadata() } }
                Button("Reset Onboarding") {
                    NSApp.sendAction(#selector(NSApplication.newWindowForTab(_:)), to: nil, from: nil)
                }
            }
        }
    }
}

struct SettingsSidebarGroup: View {
    let title: String
    let sections: [SettingsSection]
    @Binding var selection: SettingsSection
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(SettingsPalette.text)
                .padding(.horizontal, 6)

            VStack(spacing: 6) {
                ForEach(sections) { section in
                    SettingsSidebarRow(section: section, isSelected: selection == section, accent: accent) {
                        withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) {
                            selection = section
                        }
                    }
                }
            }
        }
    }
}

struct SettingsSidebarRow: View {
    let section: SettingsSection
    let isSelected: Bool
    let accent: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .fill(accent.opacity(0.18))
                        .frame(width: 34, height: 34)
                    Image(systemName: section.icon)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(SettingsPalette.text)
                }

                Text(section.rawValue)
                    .font(.system(size: 15, weight: isSelected ? .semibold : .medium))
                    .foregroundStyle(isSelected ? SettingsPalette.text : SettingsPalette.secondaryText)
                Spacer()
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(isSelected ? SettingsPalette.accent.opacity(0.13) : Color.clear, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

struct SettingsCard<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(SettingsPalette.text)

            VStack(spacing: 10) {
                content
            }
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white.opacity(0.26), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(.white.opacity(0.32), lineWidth: 0.8)
            }
        }
    }
}

struct SourceTile: View {
    let title: String
    let icon: String
    let source: PlaybackSource
    @Binding var selection: PlaybackSource

    private var appIcon: NSImage? {
        switch source {
        case .appleMusic:
            return NSWorkspace.shared.icon(forFile: "/System/Applications/Music.app")
        case .spotify:
            return NSWorkspace.shared.icon(forFile: "/Applications/Spotify.app")
        default:
            return nil
        }
    }

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                selection = source
            }
        } label: {
            VStack(spacing: 12) {
                Group {
                    if let appIcon {
                        Image(nsImage: appIcon)
                            .resizable()
                            .interpolation(.high)
                            .scaledToFit()
                            .padding(10)
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 32, weight: .bold))
                    }
                }
                .frame(width: 54, height: 54)
                .background(.white.opacity(0.14), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                Text(title)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(SettingsPalette.text)
            }
            .frame(width: 112, height: 112)
            .background(SettingsPalette.accent.opacity(selection == source ? 0.18 : 0.08), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(selection == source ? SettingsPalette.accent.opacity(0.75) : Color.clear, lineWidth: 2)
            }
        }
        .buttonStyle(.plain)
    }
}

struct ModeTile: View {
    let mode: MiniPlayerMode
    @Binding var selection: MiniPlayerMode
    let accent: Color

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                selection = mode
            }
        } label: {
            VStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(SettingsPalette.text)
                Text(mode.rawValue)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(SettingsPalette.text)
            }
            .frame(width: 130, height: 96)
            .background(accent.opacity(selection == mode ? 0.20 : 0.08), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .strokeBorder(selection == mode ? accent.opacity(0.75) : Color.clear, lineWidth: 2)
            }
        }
        .buttonStyle(.plain)
    }

    private var icon: String {
        switch mode {
        case .compact: "capsule.fill"
        case .expanded: "rectangle.roundedtop.fill"
        case .lyricsFocus: "quote.bubble.fill"
        }
    }
}

struct SettingsToggleRow: View {
    let icon: String
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(SettingsPalette.secondaryAccent)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(SettingsPalette.text)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(SettingsPalette.secondaryText)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .labelsHidden()
                .toggleStyle(.switch)
        }
        .padding(.vertical, 6)
    }
}

struct SettingsSliderRow<Value: BinaryFloatingPoint>: View {
    let icon: String
    let title: String
    @Binding var value: Value
    let range: ClosedRange<Value>

    private var doubleBinding: Binding<Double> {
        Binding<Double>(
            get: { Double(value) },
            set: { value = Value($0) }
        )
    }

    private var doubleRange: ClosedRange<Double> {
        Double(range.lowerBound)...Double(range.upperBound)
    }

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(SettingsPalette.secondaryAccent)
                .frame(width: 28)
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(SettingsPalette.text)
            Slider(value: doubleBinding, in: doubleRange)
                .frame(maxWidth: 220)
        }
        .padding(.vertical, 6)
    }
}

struct SettingsStaticRow: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(SettingsPalette.secondaryAccent)
                .frame(width: 28)
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(SettingsPalette.text)
            Spacer()
            Text(subtitle)
                .font(.caption.weight(.semibold))
                .foregroundStyle(SettingsPalette.secondaryText)
        }
        .padding(.vertical, 6)
    }
}

struct SettingsStatusRow: View {
    var title: String
    var state: BackendPermissionState

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(SettingsPalette.text)
            Spacer()
            Label(label, systemImage: icon)
                .foregroundStyle(color)
        }
        .font(.callout)
        .padding(.vertical, 6)
    }

    private var label: String {
        switch state {
        case .unknown: "Not Checked"
        case .ready: "Ready"
        case .unavailable(let message): message
        }
    }

    private var icon: String {
        switch state {
        case .unknown: "questionmark.circle"
        case .ready: "checkmark.circle.fill"
        case .unavailable: "exclamationmark.triangle.fill"
        }
    }

    private var color: Color {
        switch state {
        case .unknown: SettingsPalette.secondaryText
        case .ready: .green
        case .unavailable: .orange
        }
    }
}

enum SettingsPalette {
    static let accent = Color(red: 0.36, green: 0.42, blue: 0.34)
    static let secondaryAccent = Color(red: 0.53, green: 0.49, blue: 0.40)
    static let text = Color(red: 0.14, green: 0.14, blue: 0.12)
    static let secondaryText = Color(red: 0.34, green: 0.34, blue: 0.30)
}

struct DiagonalSettingsTexture: View {
    var body: some View {
        Canvas { context, size in
            let spacing: CGFloat = 22
            let lineColor = Color.white.opacity(0.38)
            var path = Path()

            var x: CGFloat = -size.height
            while x < size.width {
                path.move(to: CGPoint(x: x, y: size.height))
                path.addLine(to: CGPoint(x: x + size.height, y: 0))
                x += spacing
            }

            context.stroke(path, with: .color(lineColor), lineWidth: 0.6)
        }
        .allowsHitTesting(false)
    }
}

       
