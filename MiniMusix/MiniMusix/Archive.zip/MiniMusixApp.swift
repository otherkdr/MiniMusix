//
//  MiniMusixApp.swift
//  MiniMusix
//
//  Created by khadar on 6/2/26.
//

import SwiftUI

@main
struct MiniMusixApp: App {
    @StateObject private var store = NowPlayingStore()
    @Environment(\.openWindow) private var openWindow

    var body: some Scene {
        WindowGroup {
            ContentView(store: store)
                .tint(Color(red: 0.37, green: 0.42, blue: 0.34))
        }
        .windowStyle(.hiddenTitleBar)
        .windowResizability(.contentSize)

        Window("MiniMusix Settings", id: "settings") {
            MiniMusixSettingsView(store: store)
                .tint(Color(red: 0.37, green: 0.42, blue: 0.34))
        }
        .windowResizability(.contentSize)
        .commands {
            CommandGroup(replacing: .appSettings) {
                Button("Settings...") {
                    openWindow(id: "settings")
                }
                .keyboardShortcut(",", modifiers: .command)
            }
        }
    }
}
