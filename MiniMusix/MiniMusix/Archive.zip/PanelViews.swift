import SwiftUI

struct QueuePanel: View {
    @ObservedObject var store: NowPlayingStore
    var close: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                GlassIconButton(systemName: "xmark", label: "Close Queue", tint: store.currentTrack?.dominantColor ?? .secondary, size: 30, action: close)
                Spacer()
                Text("Queue")
                    .font(.headline)
                Spacer()
                GlassIconButton(systemName: "plus", label: "Add Current Track", tint: store.currentTrack?.dominantColor ?? .secondary, size: 30) {
                    store.addCurrentTrackToQueue()
                }
            }

            VStack(alignment: .leading, spacing: 9) {
                Text("Now Playing")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                if let currentTrack = store.currentTrack {
                    QueueRow(track: currentTrack, isCurrent: true)
                } else {
                    Text("Not Playing")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 8)
                }
            }

            Divider().opacity(0.5)

            VStack(alignment: .leading, spacing: 9) {
                Text("Up Next")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)

                if store.queue.isEmpty {
                    Text("No queued tracks")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 8)
                }

                ForEach(store.queue) { item in
                    QueueRow(track: item.track, isCurrent: false, play: {
                        store.playQueueItem(item)
                    }) {
                        store.removeFromQueue(item)
                    }
                    if item.id != store.queue.last?.id {
                        Divider().opacity(0.28)
                    }
                }
                .onMove { source, destination in
                    store.moveQueueItems(from: source, to: destination)
                }
            }
        }
        .padding(14)
        .frame(width: 254)
        .glassEffect(.regular.tint((store.currentTrack?.dominantColor ?? .secondary).opacity(0.09)).interactive(), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(.white.opacity(0.15), lineWidth: 0.8)
        }
        .shadow(color: (store.currentTrack?.dominantColor ?? .secondary).opacity(0.08), radius: 16, y: 8)
        .transition(.scale(scale: 0.86, anchor: .bottomLeading).combined(with: .opacity))
    }
}

struct QueueRow: View {
    var track: NowPlayingTrack
    var isCurrent: Bool
    var play: (() -> Void)?
    var remove: (() -> Void)?

    var body: some View {
        Button {
            play?()
        } label: {
            HStack(spacing: 10) {
                AlbumArtworkView(track: track, size: 34, glow: false)
                VStack(alignment: .leading, spacing: 2) {
                    MarqueeText(
                        text: track.identity.title,
                        font: .caption.weight(isCurrent ? .semibold : .regular)
                    )

                    MarqueeText(
                        text: track.identity.artist,
                        font: .caption2
                    )
                    .foregroundStyle(.secondary)
                }
                Spacer()
                if isCurrent {
                    Image(systemName: "speaker.wave.2.fill")
                        .foregroundStyle(track.dominantColor)
                        .symbolEffect(.pulse, options: .repeating, isActive: track.playbackState == .playing)
                } else if let remove {
                    Button(action: remove) {
                        Image(systemName: "minus.circle")
                            .font(.caption.weight(.semibold))
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.secondary)
                    .help("Remove from Queue")
                }
            }
        }
        .buttonStyle(.plain)
        .disabled(play == nil)
    }
}

struct MarqueeText: View {
    let text: String
    let font: Font

    @State private var animate = false

    var body: some View {
        GeometryReader { geometry in
            let estimatedWidth = CGFloat(text.count) * 7.5
            let needsScrolling = estimatedWidth > geometry.size.width

            Group {
                if needsScrolling {
                    HStack(spacing: 40) {
                        Text(text)
                        Text(text)
                    }
                    .font(font)
                    .lineLimit(1)
                    .offset(x: animate ? -(estimatedWidth + 40) : 0)
                    .onAppear {
                        animate = false
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation(
                                .linear(duration: max(8, estimatedWidth / 22))
                                .repeatForever(autoreverses: false)
                            ) {
                                animate = true
                            }
                        }
                    }
                } else {
                    Text(text)
                        .font(font)
                        .lineLimit(1)
                }
            }
        }
        .frame(height: 18)
        .clipped()
    }
}

struct LyricsPanel: View {
    @ObservedObject var store: NowPlayingStore
    var close: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Spacer()
                Text("Lyrics")
                    .font(.headline)
                Spacer()
                GlassIconButton(systemName: "xmark", label: "Close Lyrics", tint: store.currentTrack?.secondaryColor ?? .secondary, size: 30, action: close)
            }

            switch store.lyrics {
            case .loading:
                LyricsLoadingView()
            case .synced(let lines):
                SyncedLyricsView(lines: lines, elapsed: store.currentTrack?.elapsed ?? 0, fontSize: store.settings.lyricFontSize)
            case .plain(let text):
                ScrollView {
                    Text(text)
                        .font(.system(size: store.settings.lyricFontSize, weight: .medium))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .textSelection(.enabled)
                }
                .frame(height: 164)
            case .unavailable:
                UnavailableLyricsView(message: store.settings.missingLyricsMessage)
            }
        }
        .padding(14)
        .frame(width: 278)
        .glassEffect(.regular.tint((store.currentTrack?.secondaryColor ?? .secondary).opacity(0.09)).interactive(), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(.white.opacity(0.15), lineWidth: 0.8)
        }
        .shadow(color: (store.currentTrack?.secondaryColor ?? .secondary).opacity(0.08), radius: 16, y: 8)
        .transition(.scale(scale: 0.86, anchor: .bottomTrailing).combined(with: .opacity))
    }
}

struct LyricsLoadingView: View {
    var body: some View {
        VStack(spacing: 12) {
            ProgressView()
                .controlSize(.small)
            Text("Fetching lyrics")
                .font(.headline)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 164)
    }
}

struct SyncedLyricsView: View {
    var lines: [SyncedLyricLine]
    var elapsed: TimeInterval
    var fontSize: CGFloat

    private var currentIndex: Int {
        let adjustedElapsed = elapsed + lyricLeadTime
        guard let index = lines.lastIndex(where: { $0.time <= adjustedElapsed }) else { return 0 }
        return index
    }

    var body: some View {
        ZStack(alignment: .leading) {
            ForEach(displayLines) { item in
                let offset = relativeOffset(for: item)
                let isCurrent = offset == 0

                Text(item.text)
                    .font(.system(size: isCurrent ? currentLineFontSize : supportingLineFontSize, weight: isCurrent ? .semibold : .medium))
                    .foregroundStyle(isCurrent ? .primary : .secondary)
                    .lineLimit(isCurrent ? 2 : 1)
                    .minimumScaleFactor(isCurrent ? 0.68 : 0.82)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .opacity(opacity(for: offset))
                    .scaleEffect(isCurrent ? 1.0 : 0.96, anchor: .leading)
                    .offset(y: yOffset(for: offset))
                    .blur(radius: isCurrent ? 0 : 0.15)
                    .contentTransition(.opacity)
            }
        }
        .frame(height: 164, alignment: .center)
        .clipped()
        .animation(.interpolatingSpring(stiffness: 210, damping: 27), value: currentIndex)
    }

    private var lyricLeadTime: TimeInterval {
        0.18
    }

    private var currentLineFontSize: CGFloat {
        min(max(fontSize + 3, 21), 29)
    }

    private var supportingLineFontSize: CGFloat {
        min(max(fontSize - 4, 14), 18)
    }

    private func relativeOffset(for line: SyncedLyricLine) -> Int {
        guard let index = lines.firstIndex(where: { $0.id == line.id }) else { return 0 }
        return index - currentIndex
    }

    private func yOffset(for offset: Int) -> CGFloat {
        switch offset {
        case -2: return -86
        case -1: return -46
        case 0: return 0
        case 1: return 48
        case 2: return 88
        default: return CGFloat(offset) * 44
        }
    }

    private func opacity(for offset: Int) -> Double {
        switch abs(offset) {
        case 0: return 1.0
        case 1: return 0.48
        case 2: return 0.18
        default: return 0
        }
    }

    private var displayLines: [SyncedLyricLine] {
        guard !lines.isEmpty else { return [] }
        let lower = max(0, currentIndex - 2)
        let upper = min(lines.count - 1, currentIndex + 2)
        return Array(lines[lower...upper])
    }
}

struct UnavailableLyricsView: View {
    var message: String

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "text.bubble")
                .font(.system(size: 34, weight: .semibold))
                .foregroundStyle(.secondary)
            Text(message)
                .font(.headline)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 164)
    }
}
