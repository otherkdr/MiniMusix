import SwiftUI
import Combine
import AppKit

struct ContentView: View {
    @ObservedObject var store: NowPlayingStore
    @Environment(\.openWindow) private var openWindow
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var presentation = MiniPlayerPresentationController()
    @StateObject private var lockscreenSurface = LockScreenSurfaceController()
    @State private var didCompleteOnboarding = false
    @State private var onboardingIsIntro = true
    @State private var compactSurfaceFrame: NSRect = .zero
    @Namespace private var namespace

    private let tickTimer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        Group {
            if didCompleteOnboarding {
                floatingPlayer
            } else {
                OnboardingView(store: store, isIntroPhase: $onboardingIsIntro) {
                    didCompleteOnboarding = true
                    onboardingIsIntro = true
                    presentation.applyPreferredMode(store.settings.preferredMode)
                }
            }
        }
        .background(
            WindowConfigurator(
                alwaysOnTop: store.settings.alwaysOnTop,
                hiddenFromCapture: store.settings.hideFromScreenCapture,
                size: windowSize,
                isOnboarding: !didCompleteOnboarding,
                hiddenForLockscreen: didCompleteOnboarding && presentation.lockscreenVisible
            ) { frame in
                guard !presentation.lockscreenVisible else { return }
                compactSurfaceFrame = frame
            }
        )
        .environmentObject(store)
        .task {
            await store.refreshMetadata()
        }
        .onReceive(tickTimer) { _ in
            store.tick()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.sessionDidResignActiveNotification)) { _ in
            guard didCompleteOnboarding else { return }
            presentation.enterSystemLockscreenOverlay()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.sessionDidBecomeActiveNotification)) { _ in
            presentation.exitSystemLockscreenOverlayIfNeeded()
        }
        .onChange(of: presentation.lockscreenVisible) { _, isVisible in
            if isVisible {
                lockscreenSurface.present(
                    store: store,
                    presentation: presentation,
                    from: compactSurfaceFrame,
                    reduceMotion: reduceMotion
                ) {
                    presentation.exitLockscreen()
                }
            } else {
                lockscreenSurface.dismiss(to: compactSurfaceFrame, reduceMotion: reduceMotion)
            }
        }
        .onChange(of: presentation.lockscreenLyricsVisible) { _, _ in
            refreshLockscreenSurfaceIfNeeded()
        }
        .onChange(of: store.currentTrack) { _, _ in
            refreshLockscreenSurfaceIfNeeded()
        }
        .onChange(of: store.lyrics) { _, _ in
            refreshLockscreenSurfaceIfNeeded()
        }
    }

    private var floatingPlayer: some View {
        GlassEffectContainer(spacing: 18) {
            compactPlayer
        }
    }

    private var compactPlayer: some View {
        HStack(alignment: .bottom, spacing: 12) {
                if store.settings.queueButtonEnabled {
                    if presentation.showingQueue {
                        QueuePanel(store: store) {
                            animate {
                                presentation.hideQueue()
                            }
                        }
                        .matchedGeometryEffect(id: "queue", in: namespace)
                    } else {
                        SideGlassButton(systemName: "text.line.first.and.arrowtriangle.forward", label: "Queue", tint: store.currentTrack?.dominantColor ?? .secondary) {
                            animate {
                                presentation.showQueue()
                            }
                        }
                        .matchedGeometryEffect(id: "queue", in: namespace)
                    }
                }

                MiniPlayerPill(
                    store: store,
                    mode: presentation.miniPlayerMode,
                    namespace: namespace
                )
                    .onTapGesture(count: 2) {
                        animate {
                            presentation.toggleCompactExpanded()
                        }
                    }
                    .contextMenu {
                        Button("Compact") { presentation.selectCompact() }
                        Button("Expanded") { presentation.selectExpanded() }
                        Button("Lyrics Focus") {
                            presentation.showLyricsFocus()
                        }
                        Divider()
                        Button("Settings") {
                            openWindow(id: "settings")
                        }
                        Button("Refresh Metadata") {
                            Task { await store.refreshMetadata() }
                        }
                    }

                if presentation.showingLyrics {
                    LyricsPanel(store: store) {
                        animate {
                            presentation.hideRegularLyrics()
                        }
                    }
                    .matchedGeometryEffect(id: "lyrics", in: namespace)
                } else {
                    SideGlassButton(systemName: "quote.bubble", label: "Lyrics", tint: store.currentTrack?.secondaryColor ?? .secondary) {
                        animate {
                            presentation.showRegularLyrics()
                        }
                    }
                    .matchedGeometryEffect(id: "lyrics", in: namespace)
                }
            }
            .padding(18)
    }

    private var windowSize: CGSize {
        presentation.windowSize(didCompleteOnboarding: didCompleteOnboarding, onboardingIsIntro: onboardingIsIntro)
    }

    private func refreshLockscreenSurfaceIfNeeded() {
        guard presentation.lockscreenVisible else { return }
        lockscreenSurface.update(
            store: store,
            presentation: presentation,
            reduceMotion: reduceMotion
        ) {
            presentation.exitLockscreen()
        }
    }

    private func animate(_ changes: @escaping () -> Void) {
        if reduceMotion {
            changes()
        } else {
            withAnimation(.spring(response: 0.56, dampingFraction: 0.86), changes)
        }
    }
}

#Preview {
    ContentView(store: NowPlayingStore())
}
