import SwiftUI
import Combine

@MainActor
final class MiniPlayerPresentationController: ObservableObject {
    @Published var mode: MiniPlayerPresentationMode = .compact
    @Published var showingQueue = false
    @Published var showingLyrics = false
    @Published var lockscreenVisible = false
    @Published var lockscreenLyricsVisible = false

    private var enteredForSystemLock = false

    var miniPlayerMode: MiniPlayerMode {
        mode.miniPlayerMode
    }

    func applyPreferredMode(_ preferredMode: MiniPlayerMode) {
        mode = MiniPlayerPresentationMode(miniPlayerMode: preferredMode)
        enteredForSystemLock = false
        lockscreenVisible = false
        showingQueue = false
        showingLyrics = false
        lockscreenLyricsVisible = false
    }

    func selectCompact() {
        mode = .compact
        showingLyrics = false
        lockscreenLyricsVisible = false
    }

    func selectExpanded() {
        mode = .expanded
        lockscreenLyricsVisible = false
    }

    func toggleCompactExpanded() {
        mode = mode == .compact ? .expanded : .compact
    }

    func enterSystemLockscreenOverlay() {
        enteredForSystemLock = true
        showingQueue = false
        showingLyrics = false
        lockscreenLyricsVisible = false
        lockscreenVisible = true
    }

    func exitLockscreen() {
        lockscreenLyricsVisible = false
        enteredForSystemLock = false
        lockscreenVisible = false
    }

    func exitSystemLockscreenOverlayIfNeeded() {
        guard enteredForSystemLock else { return }
        exitLockscreen()
    }

    func toggleLockscreenLyrics() {
        guard lockscreenVisible else { return }
        lockscreenLyricsVisible.toggle()
    }

    func showQueue() {
        guard !lockscreenVisible else { return }
        showingQueue = true
        showingLyrics = false
    }

    func hideQueue() {
        showingQueue = false
    }

    func showRegularLyrics() {
        guard !lockscreenVisible else { return }
        showingLyrics = true
        showingQueue = false
    }

    func hideRegularLyrics() {
        showingLyrics = false
    }

    func showLyricsFocus() {
        mode = .expanded
        showingLyrics = true
        showingQueue = false
        lockscreenLyricsVisible = false
    }

    func windowSize(didCompleteOnboarding: Bool, onboardingIsIntro: Bool) -> CGSize {
        guard didCompleteOnboarding else {
            return onboardingIsIntro ? CGSize(width: 540, height: 540) : CGSize(width: 1020, height: 620)
        }

        if showingQueue || showingLyrics {
            return CGSize(width: 792, height: 286)
        }

        return mode == .compact ? CGSize(width: 560, height: 120) : CGSize(width: 680, height: 180)
    }
}
