import SwiftUI
import Combine

// MARK: - Onboarding Settings State

struct OnboardingSettings {
    // Step 1 – Style
    var playerMode: MiniPlayerMode = .compact

    // Step 2 – Appearance
    var albumTint: Double      = 0.10
    var artworkGlow: Bool      = true
    var glassIntensity: Double = 0.72
    var barGradient: Bool      = true

    // Step 3 – Behavior
    var floatAbove: Bool          = true
    var hideOnStop: Bool          = false
    var launchAtLogin: Bool       = false
    var showQueueButton: Bool     = true
    var showLyricsButton: Bool    = true

    // Step 4 – Lyrics
    var lyricsEnabled: Bool       = true
    var preferSynced: Bool        = true
    var plainFallback: Bool       = true

    // Appearance passthrough
    var glassStyle: OnboardingGlassStyle = .regular
}

// MARK: - Glass Style Enum

enum OnboardingGlassStyle: String, CaseIterable, Identifiable {
    case clear   = "Clear"
    case regular = "Regular"
    case soft    = "Soft"
    var id: String { rawValue }
    var tintOpacity: Double {
        switch self { case .clear: 0.035; case .regular: 0.075; case .soft: 0.12 }
    }
}

// MARK: - Onboarding Step

enum OnboardingStep: Int, CaseIterable {
    case style       = 1
    case appearance  = 2
    case behavior    = 3
    case lyrics      = 4
    case permissions = 5
    case finalPreview = 6

    var title: String {
        switch self {
        case .style:        return "Choose Your Style"
        case .appearance:   return "Appearance"
        case .behavior:     return "Behavior"
        case .lyrics:       return "Lyrics"
        case .permissions:  return "Permissions"
        case .finalPreview: return "You're All Set"
        }
    }

    var subtitle: String {
        switch self {
        case .style:        return "Pick a layout that fits how you listen."
        case .appearance:   return "Make it yours. Every change reflects live."
        case .behavior:     return "Decide how MiniMusix fits into your workflow."
        case .lyrics:       return "MiniMusix uses LRCLIB — free, no account needed."
        case .permissions:  return "A few things may need access to work fully."
        case .finalPreview: return "Here's your configured MiniMusix."
        }
    }

    var icon: String {
        switch self {
        case .style:        return "rectangle.3.group"
        case .appearance:   return "paintpalette"
        case .behavior:     return "gearshape.2"
        case .lyrics:       return "quote.bubble"
        case .permissions:  return "lock.shield"
        case .finalPreview: return "sparkles"
        }
    }
}

// MARK: - Root Onboarding View

struct OnboardingView: View {
    @ObservedObject var store: NowPlayingStore
    @Binding var isIntroPhase: Bool
    var continueAction: () -> Void

    // Intro sequence
    @State private var logoVisible      = false
    @State private var titleStarted     = false
    @State private var typedCount       = 0
    @State private var subtitleVisible  = false
    @State private var taglineVisible   = false
    @State private var buttonVisible    = false
    @State private var continueHovered  = false
    @State private var titleLifted      = false
    @State private var introGlowPulse   = false
    @State private var introUnlocked    = false

    // Phase
    @State private var phase: OnboardingPhase = .intro

    // Steps
    @State private var currentStep: OnboardingStep = .style
    @State private var stepDirection: Int = 1   // +1 forward, -1 backward

    // Shared settings accumulator
    @State private var settings = OnboardingSettings()

    // Finishing animation
    @State private var finishScale: CGFloat  = 1.0
    @State private var finishOpacity: Double = 1.0

    private let titleText = "MiniMusix"
    private let titleTimer = Timer.publish(every: 0.092, on: .main, in: .common).autoconnect()

    // Palette
    private let accent          = Color(red: 0.36, green: 0.42, blue: 0.34)
    private let secondaryAccent = Color(red: 0.53, green: 0.49, blue: 0.40)
    private let textColor       = Color(red: 0.14, green: 0.14, blue: 0.12)
    private let secondaryText   = Color(red: 0.34, green: 0.34, blue: 0.30)

    var body: some View {
        ZStack {
            onboardingBackground
            diagonalTexture

            switch phase {
            case .intro:
                introLayout
                    .transition(.opacity)
            case .steps:
                stepsLayout
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal:   .opacity
                    ))
            }
        }
        .frame(width: frameWidth, height: frameHeight)
        .clipShape(RoundedRectangle(cornerRadius: 36, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .strokeBorder(
                    LinearGradient(
                        colors: [.white.opacity(0.72), .white.opacity(0.28)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ),
                    lineWidth: 1.0
                )
        }
        .shadow(color: .black.opacity(0.10), radius: 40, y: 20)
        .shadow(color: accent.opacity(0.06),  radius: 60, y: 30)
        .tint(accent)
        .scaleEffect(finishScale)
        .opacity(finishOpacity)
        .animation(.spring(response: 0.78, dampingFraction: 0.88), value: phase)
        .onAppear(perform: startReveal)
        .onChange(of: phase) { _, newPhase in
            isIntroPhase = newPhase == .intro
        }
        .onReceive(titleTimer) { _ in
            guard titleStarted, typedCount < titleText.count else { return }
            typedCount += 1
            if typedCount == titleText.count {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
                    withAnimation(.spring(response: 0.44, dampingFraction: 0.78)) {
                        subtitleVisible = true
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.58) {
                    withAnimation(.spring(response: 0.42, dampingFraction: 0.76)) {
                        buttonVisible = true
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 0.86) {
                    withAnimation(.spring(response: 0.24, dampingFraction: 0.58)) {
                        titleLifted = true
                        introGlowPulse = true
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 1.08) {
                    withAnimation(.interpolatingSpring(stiffness: 430, damping: 16)) {
                        titleLifted = false
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 1.86) {
                    withAnimation(.easeOut(duration: 0.42)) {
                        introGlowPulse = false
                        taglineVisible = true
                        introUnlocked = true
                    }
                }
            }
        }
    }

    private var frameWidth: CGFloat  { phase == .intro ? 540 : 1020 }
    private var frameHeight: CGFloat { phase == .intro ? 540 :  620 }

    // MARK: – Intro

    private var introLayout: some View {
        VStack(spacing: 22) {
            MiniMusixLogo(size: 82)
                .scaleEffect(logoVisible ? (titleLifted ? 1.055 : 1.0) : 0.58)
                .opacity(logoVisible ? 1 : 0)
                .rotationEffect(.degrees(logoVisible ? 0 : -7))
                .offset(y: titleLifted ? -10 : 0)
                .shadow(color: accent.opacity(introGlowPulse ? 0.32 : 0.0), radius: introGlowPulse ? 26 : 0, y: 0)

            VStack(spacing: 10) {
                Text(String(titleText.prefix(typedCount)))
                    .font(.system(size: 54, weight: .bold, design: .rounded))
                    .foregroundStyle(textColor)
                    .lineLimit(1)
                    .frame(height: 64, alignment: .center)
                    .offset(y: titleLifted ? -18 : 0)
                    .scaleEffect(titleLifted ? 1.035 : 1.0)
                    .shadow(color: accent.opacity(introGlowPulse ? 0.28 : 0.0), radius: introGlowPulse ? 24 : 0, y: 0)

                Text("A focused music companion\nfor macOS.")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(secondaryText)
                    .lineSpacing(3)
                    .multilineTextAlignment(.center)
                    .opacity(subtitleVisible ? 1 : 0)
                    .offset(y: subtitleVisible ? (titleLifted ? -6 : 0) : 10)
                    .shadow(color: accent.opacity(introGlowPulse ? 0.16 : 0.0), radius: introGlowPulse ? 18 : 0, y: 0)
            }

            Button {
                guard introUnlocked else { return }
                withAnimation(.spring(response: 0.78, dampingFraction: 0.88)) { phase = .steps }
            } label: {
                HStack(spacing: 10) {
                    Text("Continue")
                        .font(.system(size: 15, weight: .semibold))
                    Image(systemName: "arrow.right")
                        .font(.system(size: 13, weight: .bold))
                        .offset(x: continueHovered ? 3 : 0)
                        .animation(.spring(response: 0.26, dampingFraction: 0.68), value: continueHovered)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 30)
                .frame(height: 50)
                .background(accent, in: Capsule())
                .overlay { Capsule().strokeBorder(.white.opacity(0.26), lineWidth: 0.8) }
                .shadow(color: accent.opacity(introGlowPulse ? 0.38 : continueHovered ? 0.30 : 0.16),
                        radius: introGlowPulse ? 26 : continueHovered ? 18 : 10,
                        y: continueHovered ? 8 : 4)
                .scaleEffect(titleLifted ? 1.025 : continueHovered && introUnlocked ? 1.03 : 1.0)
                .offset(y: titleLifted ? -8 : 0)
                .animation(.spring(response: 0.26, dampingFraction: 0.72), value: continueHovered)
                .animation(.easeOut(duration: 0.28), value: introGlowPulse)
            }
            .buttonStyle(.plain)
            .onHover { continueHovered = $0 }
            .opacity(buttonVisible ? 1 : 0)
            .offset(y: buttonVisible ? 0 : -24)
            .disabled(!introUnlocked)

            Text("Free & open source  ·  No account required")
                .font(.system(size: 11.5, weight: .medium))
                .foregroundStyle(secondaryText.opacity(0.55))
                .opacity(taglineVisible ? 1 : 0)
                .offset(y: taglineVisible ? 0 : -6)
        }
        .frame(width: 540, height: 540, alignment: .center)
        .padding(44)
    }

    private var introStepDots: some View {
        HStack(spacing: 7) {
            Capsule().fill(accent).frame(width: 28, height: 7)
            ForEach(0..<6) { _ in
                Capsule().fill(accent.opacity(0.28)).frame(width: 8, height: 7)
            }
        }
        .accessibilityHidden(true)
    }

    // MARK: – Steps Layout

    private var stepsLayout: some View {
        HStack(spacing: 0) {
            // ── Left panel ──────────────────────────────────────────────
            VStack(alignment: .leading, spacing: 0) {
                // Header
                HStack(spacing: 13) {
                    MiniMusixLogo(size: 34)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("MiniMusix")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundStyle(textColor)
                        Text("STEP \(currentStep.rawValue) OF \(OnboardingStep.allCases.count)")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(accent.opacity(0.65))
                            .tracking(1.2)
                    }
                    Spacer()
                    // Step progress dots
                    HStack(spacing: 5) {
                        ForEach(OnboardingStep.allCases, id: \.self) { step in
                            let active = step == currentStep
                            let done   = step.rawValue < currentStep.rawValue
                            Capsule()
                                .fill(done ? accent.opacity(0.5) : active ? accent : accent.opacity(0.22))
                                .frame(width: active ? 18 : 7, height: 6)
                                .animation(.spring(response: 0.36, dampingFraction: 0.76), value: currentStep)
                        }
                    }
                    .accessibilityHidden(true)
                }
                .padding(.top, 28)
                .padding(.horizontal, 32)

                thinDividerH
                    .padding(.top, 16)
                    .padding(.horizontal, 24)

                // Step title
                VStack(alignment: .leading, spacing: 5) {
                    HStack(spacing: 9) {
                        Image(systemName: currentStep.icon)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(accent)
                        Text(currentStep.title)
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundStyle(textColor)
                    }
                    Text(currentStep.subtitle)
                        .font(.system(size: 13))
                        .foregroundStyle(secondaryText)
                        .lineSpacing(2)
                }
                .padding(.horizontal, 32)
                .padding(.top, 18)

                // Step content (animated slide)
                stepContentPanel
                    .padding(.horizontal, 28)
                    .padding(.top, 16)

                Spacer(minLength: 0)

                // Navigation
                navBar
                    .padding(.horizontal, 28)
                    .padding(.bottom, 26)
            }
            .frame(width: 430)

            // ── Vertical divider ────────────────────────────────────────
            thinDivider.padding(.vertical, 28)

            // ── Right: live preview ─────────────────────────────────────
            VStack(spacing: 0) {
                Spacer()
                OnboardingLivePreview(
                    settings: settings,
                    previewStage: previewStageForCurrentStep
                )
                .padding(.horizontal, 40)
                Spacer()

                WaveformDecoration(color: accent)
                    .frame(height: 28)
                    .padding(.horizontal, 52)
                    .padding(.bottom, 24)
                    .opacity(0.30)
            }
            .frame(maxWidth: .infinity)
        }
    }

    private var previewStageForCurrentStep: PreviewStage {
        switch currentStep {
        case .style:       return .pill
        case .appearance:  return .pill
        case .behavior:    return currentStep == .behavior ? .withButtons : .pill
        case .lyrics:      return .withLyrics
        case .permissions: return .withButtons
        case .finalPreview: return .full
        }
    }

    // MARK: – Step Content

    @ViewBuilder
    private var stepContentPanel: some View {
        ZStack {
            // We use id to force re-creation on step change, driving the transition
            Group {
                switch currentStep {
                case .style:
                    Step1StylePanel(selection: $settings.playerMode,
                                    accent: accent, textColor: textColor, secondaryText: secondaryText)
                case .appearance:
                    Step2AppearancePanel(settings: $settings,
                                        accent: accent, secondaryAccent: secondaryAccent,
                                        textColor: textColor, secondaryText: secondaryText)
                case .behavior:
                    Step3BehaviorPanel(settings: $settings,
                                      accent: accent, textColor: textColor, secondaryText: secondaryText)
                case .lyrics:
                    Step4LyricsPanel(settings: $settings,
                                     accent: accent, textColor: textColor, secondaryText: secondaryText)
                case .permissions:
                    Step5PermissionsPanel(launchAtLogin: settings.launchAtLogin,
                                         accent: accent, textColor: textColor, secondaryText: secondaryText)
                case .finalPreview:
                    Step6FinalPanel(accent: accent, textColor: textColor, secondaryText: secondaryText)
                }
            }
            .id(currentStep)
            .transition(stepTransition)
        }
    }

    private var stepTransition: AnyTransition {
        let direction: Edge = stepDirection > 0 ? .trailing : .leading
        return .asymmetric(
            insertion:  .move(edge: direction).combined(with: .opacity),
            removal:    .move(edge: stepDirection > 0 ? .leading : .trailing).combined(with: .opacity)
        )
    }

    // MARK: – Nav Bar

    private var navBar: some View {
        HStack {
            // Back
            Button {
                guard currentStep.rawValue > 1 else {
                    withAnimation(.spring(response: 0.78, dampingFraction: 0.88)) { phase = .intro }
                    return
                }
                stepDirection = -1
                withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                    currentStep = OnboardingStep(rawValue: currentStep.rawValue - 1)!
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "chevron.left").font(.system(size: 11, weight: .bold))
                    Text(currentStep.rawValue == 1 ? "Intro" : "Back")
                        .font(.system(size: 13, weight: .medium))
                }
                .foregroundStyle(secondaryText)
                .padding(.horizontal, 16)
                .frame(height: 40)
                .background(Capsule().fill(.white.opacity(0.42)))
                .overlay { Capsule().strokeBorder(.white.opacity(0.5), lineWidth: 0.7) }
            }
            .buttonStyle(.plain)

            Spacer()

            // Skip (for permissions)
            if currentStep == .permissions {
                Button {
                    advanceStep()
                } label: {
                    Text("Skip")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(secondaryText.opacity(0.7))
                }
                .buttonStyle(.plain)
            }

            // Continue / Finish
            Button {
                if currentStep == .finalPreview {
                    finishOnboarding()
                } else {
                    advanceStep()
                }
            } label: {
                HStack(spacing: 8) {
                    Text(currentStep == .finalPreview ? "Start Using MiniMusix" : "Continue")
                        .font(.system(size: 13, weight: .semibold))
                    Image(systemName: currentStep == .finalPreview ? "music.note" : "arrow.right")
                        .font(.system(size: 12, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 20)
                .frame(height: 40)
                .background(accent, in: Capsule())
                .overlay { Capsule().strokeBorder(.white.opacity(0.24), lineWidth: 0.8) }
                .shadow(color: accent.opacity(0.22), radius: 10, y: 4)
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: – Actions

    private func advanceStep() {
        stepDirection = 1
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
            currentStep = OnboardingStep(rawValue: currentStep.rawValue + 1) ?? .finalPreview
        }
    }

    private func finishOnboarding() {
        // Commit settings to store
        store.settings.preferredMode       = settings.playerMode
        store.settings.albumTintStrength   = settings.albumTint
        store.settings.artworkGlow         = settings.artworkGlow
        store.settings.glassIntensity      = settings.glassIntensity
        store.settings.alwaysOnTop         = settings.floatAbove
        store.settings.hideWhenPlaybackStops = settings.hideOnStop
        store.settings.launchAtLogin       = settings.launchAtLogin
        store.settings.queueButtonEnabled  = settings.showQueueButton
        store.settings.enableLRCLIB        = settings.lyricsEnabled
        store.settings.syncedLyrics        = settings.preferSynced
        store.settings.plainLyrics         = settings.plainFallback

        // Animate preview shrinking toward bottom-center
        withAnimation(.spring(response: 0.72, dampingFraction: 0.84).delay(0.06)) {
            finishScale   = 0.18
            finishOpacity = 0
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) {
            continueAction()
        }
    }

    private func startReveal() {
        withAnimation(.spring(response: 0.72, dampingFraction: 0.58).delay(0.18)) { logoVisible = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.08) { titleStarted = true }
    }

    // MARK: – Shared decorative helpers

    private var thinDivider: some View {
        Rectangle()
            .fill(LinearGradient(colors: [.clear, textColor.opacity(0.07), .clear],
                                 startPoint: .top, endPoint: .bottom))
            .frame(width: 1)
    }

    private var thinDividerH: some View {
        Rectangle()
            .fill(textColor.opacity(0.08))
            .frame(height: 0.5)
    }

    private var onboardingBackground: some View {
        LinearGradient(
            colors: [Color(red: 0.94, green: 0.93, blue: 0.89),
                     Color(red: 0.90, green: 0.91, blue: 0.87)],
            startPoint: .topLeading, endPoint: .bottomTrailing
        )
    }

    private var diagonalTexture: some View {
        GeometryReader { _ in
            Canvas { ctx, size in
                ctx.opacity = 0.022
                var x: CGFloat = -size.height
                while x < size.width + size.height {
                    var path = Path()
                    path.move(to: CGPoint(x: x, y: 0))
                    path.addLine(to: CGPoint(x: x + size.height, y: size.height))
                    ctx.stroke(path, with: .color(Color(red: 0.14, green: 0.14, blue: 0.12)), lineWidth: 0.5)
                    x += 28
                }
            }
        }
        .allowsHitTesting(false)
    }
}

// MARK: - Onboarding Phase

enum OnboardingPhase { case intro, steps }

// MARK: - Preview Stage

enum PreviewStage { case pill, withButtons, withLyrics, full }

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Live Preview
// MARK: ──────────────────────────────────────────────────────────────────────

struct OnboardingLivePreview: View {
    var settings: OnboardingSettings
    var previewStage: PreviewStage

    // For animated progress
    @State private var elapsed: Double = 52
    @State private var lyricsPhase: Int = 1
    @State private var showQueuePanel: Bool = false
    @State private var showLyricsPanel: Bool = false

    private let progressTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()
    private let lyricsTimer   = Timer.publish(every: 3.2, on: .main, in: .common).autoconnect()
    private let panelTimer    = Timer.publish(every: 5.0, on: .main, in: .common).autoconnect()

    private let accent    = Color(red: 0.43, green: 0.49, blue: 0.39)
    private let secondary = Color(red: 0.70, green: 0.55, blue: 0.35)
    private let textColor = Color(red: 0.16, green: 0.16, blue: 0.14)

    private let previewLyrics: [SyncedLyricLine] = [
        SyncedLyricLine(time: 0,  text: "The window keeps a silver glow"),
        SyncedLyricLine(time: 30, text: "I hear the city breathing low"),
        SyncedLyricLine(time: 60, text: "Every turn becomes a sign"),
        SyncedLyricLine(time: 90, text: "You move in time with the skyline"),
    ]

    private var lyricsPayload: LyricsPayload {
        if !settings.lyricsEnabled { return .unavailable }
        if settings.preferSynced   { return .synced(previewLyrics) }
        if settings.plainFallback  { return .plain("The window keeps a silver glow\nI hear the city breathing low\nEvery turn becomes a sign\nYou move in time with the skyline") }
        return .unavailable
    }

    private var glassOpacity: Double { settings.glassStyle.tintOpacity + settings.albumTint }
    private var cornerRadius: CGFloat { settings.playerMode == .compact ? 30 : 34 }
    private var artworkSize: CGFloat  { settings.playerMode == .compact ? 62 : 90 }
    private var pillHeight: CGFloat   { settings.playerMode == .compact ? 94 : 130 }

    var body: some View {
        VStack(spacing: 0) {
            PreviewSectionLabel(text: "LIVE PREVIEW", accent: Color(red: 0.36, green: 0.42, blue: 0.34))
                .padding(.bottom, 16)

            HStack(alignment: .bottom, spacing: 10) {
                // Queue button / panel
                if previewStage == .full || previewStage == .withButtons {
                    if settings.showQueueButton {
                        if showQueuePanel && previewStage == .full {
                            PreviewQueuePanel(accent: accent, secondary: secondary, textColor: textColor)
                                .transition(.scale(scale: 0.86, anchor: .bottomLeading).combined(with: .opacity))
                        } else {
                            PreviewSideButton(icon: "text.line.first.and.arrowtriangle.forward",
                                             tint: accent)
                            .transition(.scale(scale: 0.88).combined(with: .opacity))
                        }
                    }
                }

                // Main pill
                mainPill
                    .frame(width: pillWidth)

                // Lyrics button / panel
                if previewStage == .full || previewStage == .withButtons || previewStage == .withLyrics {
                    if settings.showLyricsButton || previewStage == .withLyrics {
                        if showLyricsPanel && (previewStage == .full || previewStage == .withLyrics) {
                            PreviewLyricsPanel(
                                payload: lyricsPayload,
                                lyricsPhase: lyricsPhase,
                                accent: accent,
                                secondary: secondary,
                                textColor: textColor
                            )
                            .transition(.scale(scale: 0.86, anchor: .bottomTrailing).combined(with: .opacity))
                        } else {
                            PreviewSideButton(icon: "quote.bubble", tint: secondary)
                                .transition(.scale(scale: 0.88).combined(with: .opacity))
                        }
                    }
                }
            }
            .animation(.spring(response: 0.46, dampingFraction: 0.84), value: showQueuePanel)
            .animation(.spring(response: 0.46, dampingFraction: 0.84), value: showLyricsPanel)
            .animation(.spring(response: 0.46, dampingFraction: 0.84), value: settings.showQueueButton)
            .animation(.spring(response: 0.46, dampingFraction: 0.84), value: settings.showLyricsButton)
        }
        .animation(.spring(response: 0.54, dampingFraction: 0.84), value: settings.playerMode)
        .animation(.easeOut(duration: 0.28), value: settings.albumTint)
        .animation(.easeOut(duration: 0.28), value: settings.artworkGlow)
        .animation(.easeOut(duration: 0.28), value: settings.glassStyle)
        .onReceive(progressTimer) { _ in
            elapsed = elapsed >= 184 ? 0 : elapsed + 1
        }
        .onReceive(lyricsTimer) { _ in
            withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
                lyricsPhase = (lyricsPhase + 1) % previewLyrics.count
            }
        }
        .onReceive(panelTimer) { _ in
            guard previewStage == .full || previewStage == .withLyrics else { return }
            withAnimation(.spring(response: 0.48, dampingFraction: 0.84)) {
                if previewStage == .full {
                    showQueuePanel  = !showQueuePanel
                    showLyricsPanel = !showLyricsPanel
                } else {
                    showLyricsPanel = !showLyricsPanel
                }
            }
        }
    }

    private var pillWidth: CGFloat {
        switch settings.playerMode {
        case .compact:     return 340
        case .expanded:    return 420
        case .lyricsFocus: return 380
        }
    }

    private var mainPill: some View {
        HStack(spacing: settings.playerMode == .compact ? 12 : 16) {
            // Artwork
            ZStack {
                RoundedRectangle(cornerRadius: artworkSize * 0.22, style: .continuous)
                    .fill(LinearGradient(colors: [accent, secondary],
                                         startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "waveform")
                    .font(.system(size: artworkSize * 0.36, weight: .bold))
                    .foregroundStyle(.white.opacity(0.92))
            }
            .frame(width: artworkSize, height: artworkSize)
            .shadow(color: settings.artworkGlow ? accent.opacity(0.28) : .clear, radius: 14, y: 6)

            // Track info + progress
            VStack(alignment: .leading, spacing: settings.playerMode == .compact ? 5 : 8) {
                if settings.playerMode == .lyricsFocus {
                    // Lyrics focus: show a lyric line instead of track name
                    activeLyricLine
                } else {
                    Text("Silver Lining")
                        .font(settings.playerMode == .compact ? .headline : .title3.weight(.semibold))
                        .foregroundStyle(textColor)
                        .lineLimit(1)
                    Text("The Local Forecast")
                        .font(.caption.weight(.medium))
                        .foregroundStyle(textColor.opacity(0.58))
                        .lineLimit(1)
                }
                progressBar
            }
            .frame(width: settings.playerMode == .compact ? 158 : 220, alignment: .leading)

            Spacer(minLength: 0)

            // Controls
            HStack(spacing: settings.playerMode == .compact ? 7 : 9) {
                PreviewControlIcon(systemName: "backward.fill", tint: secondary,
                                   size: settings.playerMode == .compact ? 36 : 42)
                PreviewControlIcon(systemName: "pause.fill",    tint: accent,
                                   size: settings.playerMode == .compact ? 44 : 50, prominent: true)
                PreviewControlIcon(systemName: "forward.fill",  tint: secondary,
                                   size: settings.playerMode == .compact ? 36 : 42)
            }
        }
        .padding(settings.playerMode == .compact ? 12 : 16)
        .frame(height: pillHeight)
        .glassEffect(
            .regular.tint(accent.opacity(glassOpacity)),
            in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        )
        .overlay {
            if settings.barGradient {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(LinearGradient(
                        colors: [.white.opacity(0.10), secondary.opacity(settings.albumTint * 0.5), .clear],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ))
                    .allowsHitTesting(false)
            }
        }
        .overlay {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .strokeBorder(.white.opacity(0.30), lineWidth: 0.8)
                .allowsHitTesting(false)
        }
        .shadow(color: accent.opacity(0.10), radius: 20, y: 10)
    }

    private var activeLyricLine: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(previewLyrics[lyricsPhase % previewLyrics.count].text)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(textColor)
                .lineLimit(2)
                .contentTransition(.opacity)
                .animation(.spring(response: 0.42, dampingFraction: 0.86), value: lyricsPhase)
            Text("The Local Forecast")
                .font(.caption2.weight(.medium))
                .foregroundStyle(textColor.opacity(0.50))
        }
    }

    private var progressBar: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.secondary.opacity(0.16))
                if settings.barGradient {
                    Capsule()
                        .fill(LinearGradient(colors: [accent, secondary],
                                             startPoint: .leading, endPoint: .trailing))
                        .frame(width: proxy.size.width * min(elapsed / 184, 1))
                } else {
                    Capsule()
                        .fill(accent)
                        .frame(width: proxy.size.width * min(elapsed / 184, 1))
                }
            }
        }
        .frame(height: settings.playerMode == .compact ? 3 : 5)
        .animation(.linear(duration: 1), value: elapsed)
    }
}

// MARK: – Preview Sub-components

struct PreviewSideButton: View {
    var icon: String
    var tint: Color
    @State private var hovered = false

    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 17, weight: .semibold))
            .frame(width: 46, height: 46)
            .glassEffect(.regular.tint(tint.opacity(hovered ? 0.12 : 0.055)), in: Circle())
            .overlay { Circle().strokeBorder(.white.opacity(0.22), lineWidth: 0.8) }
            .scaleEffect(hovered ? 1.06 : 1.0)
            .onHover { hovered = $0 }
            .animation(.spring(response: 0.24, dampingFraction: 0.72), value: hovered)
    }
}

struct PreviewQueuePanel: View {
    var accent: Color
    var secondary: Color
    var textColor: Color

    private let items: [(String, String, String)] = [
        ("Silver Lining",  "The Local Forecast", "music.note"),
        ("Low Sun",        "Mira Vale",          "sparkles"),
        ("Quiet Current",  "North Pier",         "water.waves"),
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Queue")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(textColor)

            ForEach(Array(items.enumerated()), id: \.0) { idx, item in
                HStack(spacing: 8) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 6, style: .continuous)
                            .fill(LinearGradient(colors: [accent, secondary],
                                                  startPoint: .topLeading, endPoint: .bottomTrailing))
                        Image(systemName: item.2)
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.white)
                    }
                    .frame(width: 28, height: 28)

                    VStack(alignment: .leading, spacing: 1) {
                        Text(item.0).font(.system(size: 11, weight: idx == 0 ? .semibold : .regular))
                            .foregroundStyle(textColor).lineLimit(1)
                        Text(item.1).font(.system(size: 10)).foregroundStyle(textColor.opacity(0.55)).lineLimit(1)
                    }
                    Spacer()
                    if idx == 0 {
                        Image(systemName: "speaker.wave.2.fill")
                            .font(.system(size: 10))
                            .foregroundStyle(accent)
                    }
                }
                if idx < items.count - 1 {
                    Divider().opacity(0.25)
                }
            }
        }
        .padding(12)
        .frame(width: 190)
        .glassEffect(.regular.tint(accent.opacity(0.09)), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(.white.opacity(0.18), lineWidth: 0.8)
        }
        .shadow(color: accent.opacity(0.08), radius: 14, y: 7)
    }
}

struct PreviewLyricsPanel: View {
    var payload: LyricsPayload
    var lyricsPhase: Int
    var accent: Color
    var secondary: Color
    var textColor: Color

    private let lines: [String] = [
        "The window keeps a silver glow",
        "I hear the city breathing low",
        "Every turn becomes a sign",
        "You move in time with the skyline",
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Lyrics")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(textColor)

            switch payload {
            case .synced:
                VStack(alignment: .leading, spacing: 8) {
                    let current = lyricsPhase % lines.count
                    let prev    = current == 0 ? lines.count - 1 : current - 1
                    let next    = (current + 1) % lines.count
                    Text(lines[prev])
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(textColor.opacity(0.38))
                        .lineLimit(1)
                    Text(lines[current])
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(textColor)
                        .lineLimit(2)
                        .contentTransition(.opacity)
                    Text(lines[next])
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(textColor.opacity(0.38))
                        .lineLimit(1)
                }
                .animation(.spring(response: 0.42, dampingFraction: 0.86), value: lyricsPhase)

            case .plain(let text):
                Text(text)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(textColor.opacity(0.72))
                    .lineSpacing(3)
                    .lineLimit(5)

            case .unavailable:
                VStack(spacing: 6) {
                    Image(systemName: "text.bubble")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(textColor.opacity(0.30))
                    Text("No lyrics found")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(textColor.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            case .loading:
                VStack(spacing: 6) {
                    ProgressView()
                        .controlSize(.small)
                    Text("Fetching lyrics")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(textColor.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            }
        }
        .padding(12)
        .frame(width: 200)
        .glassEffect(.regular.tint(secondary.opacity(0.09)), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .strokeBorder(.white.opacity(0.18), lineWidth: 0.8)
        }
        .shadow(color: secondary.opacity(0.08), radius: 14, y: 7)
    }
}

struct PreviewControlIcon: View {
    var systemName: String
    var tint: Color
    var size: CGFloat
    var prominent = false
    @State private var hovered = false

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: prominent ? 17 : 13, weight: .bold))
            .foregroundStyle(Color(red: 0.16, green: 0.16, blue: 0.14))
            .frame(width: size, height: size)
            .glassEffect(.regular.tint(tint.opacity(hovered ? 0.13 : 0.07)), in: Circle())
            .overlay { Circle().strokeBorder(.white.opacity(hovered ? 0.30 : 0.18), lineWidth: 0.7) }
            .scaleEffect(hovered ? 1.06 : 1.0)
            .onHover { hovered = $0 }
            .animation(.spring(response: 0.22, dampingFraction: 0.70), value: hovered)
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 1 – Style
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step1StylePanel: View {
    @Binding var selection: MiniPlayerMode
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 10) {
            ForEach(MiniPlayerMode.allCases) { mode in
                StyleCard(
                    mode: mode,
                    selected: selection == mode,
                    accent: accent,
                    textColor: textColor,
                    secondaryText: secondaryText
                ) {
                    withAnimation(.spring(response: 0.40, dampingFraction: 0.82)) {
                        selection = mode
                    }
                }
            }
        }
    }
}

struct StyleCard: View {
    var mode: MiniPlayerMode
    var selected: Bool
    var accent: Color
    var textColor: Color
    var secondaryText: Color
    var action: () -> Void

    @State private var hovered = false

    private var icon: String {
        switch mode {
        case .compact:     return "rectangle.compress.vertical"
        case .expanded:    return "rectangle.expand.vertical"
        case .lyricsFocus: return "quote.bubble"
        }
    }

    private var description: String {
        switch mode {
        case .compact:     return "A slim pill that stays out of the way."
        case .expanded:    return "More room for artwork and track info."
        case .lyricsFocus: return "Puts the current lyric front and center."
        }
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                // Icon circle
                ZStack {
                    Circle()
                        .fill(selected ? accent : Color.white.opacity(0.52))
                        .frame(width: 40, height: 40)
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(selected ? .white : textColor.opacity(0.60))
                }
                .overlay {
                    Circle().strokeBorder(selected ? accent.opacity(0.3) : .white.opacity(0.6), lineWidth: 0.8)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(mode.rawValue)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(textColor)
                    Text(description)
                        .font(.system(size: 12))
                        .foregroundStyle(secondaryText.opacity(0.78))
                }

                Spacer()

                // Checkmark
                ZStack {
                    Circle()
                        .fill(selected ? accent : Color.white.opacity(0.0))
                        .frame(width: 22, height: 22)
                    if selected {
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.white)
                    } else {
                        Circle()
                            .strokeBorder(textColor.opacity(0.20), lineWidth: 1.2)
                            .frame(width: 22, height: 22)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(selected ? accent.opacity(0.08) : Color.white.opacity(hovered ? 0.52 : 0.36))
            )
            .overlay {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .strokeBorder(
                        selected ? accent.opacity(0.35) : .white.opacity(hovered ? 0.55 : 0.40),
                        lineWidth: selected ? 1.2 : 0.8
                    )
            }
            .shadow(color: selected ? accent.opacity(0.10) : .clear, radius: 8, y: 4)
        }
        .buttonStyle(.plain)
        .onHover { hovered = $0 }
        .scaleEffect(hovered && !selected ? 1.008 : 1.0)
        .animation(.spring(response: 0.26, dampingFraction: 0.74), value: hovered)
        .animation(.spring(response: 0.36, dampingFraction: 0.80), value: selected)
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 2 – Appearance
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step2AppearancePanel: View {
    @Binding var settings: OnboardingSettings
    var accent: Color
    var secondaryAccent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 0) {
            // Toggle rows
            AppearanceToggleRow(
                icon: "paintpalette.fill",
                title: "Album Color Tint",
                description: "Tints the glass surface with the album's dominant color.",
                isOn: Binding(
                    get: { settings.albumTint > 0.01 },
                    set: { settings.albumTint = $0 ? 0.10 : 0 }
                ),
                accent: accent, textColor: textColor, secondaryText: secondaryText
            )
            Divider().opacity(0.18).padding(.horizontal, 4)

            AppearanceToggleRow(
                icon: "sun.max.fill",
                title: "Artwork Glow",
                description: "Casts a soft colored shadow below the artwork.",
                isOn: $settings.artworkGlow,
                accent: accent, textColor: textColor, secondaryText: secondaryText
            )
            Divider().opacity(0.18).padding(.horizontal, 4)

            AppearanceToggleRow(
                icon: "sparkle",
                title: "Playback Bar Gradient",
                description: "Colors the progress bar with the album palette.",
                isOn: $settings.barGradient,
                accent: accent, textColor: textColor, secondaryText: secondaryText
            )
            Divider().opacity(0.18).padding(.horizontal, 4)

            // Glass intensity slider
            AppearanceSliderRow(
                icon: "circle.lefthalf.filled",
                title: "Glass Intensity",
                value: $settings.glassIntensity,
                range: 0.25...1.0,
                displayValue: "\(Int(settings.glassIntensity * 100))%",
                accent: accent, secondaryAccent: secondaryAccent,
                textColor: textColor, secondaryText: secondaryText
            )
            Divider().opacity(0.18).padding(.horizontal, 4)

            // Album tint slider (only if tint enabled)
            if settings.albumTint > 0.01 {
                AppearanceSliderRow(
                    icon: "drop.fill",
                    title: "Tint Strength",
                    value: $settings.albumTint,
                    range: 0.02...0.20,
                    displayValue: "\(Int(settings.albumTint / 0.20 * 100))%",
                    accent: accent, secondaryAccent: secondaryAccent,
                    textColor: textColor, secondaryText: secondaryText
                )
            }
        }
        .padding(6)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(.white.opacity(0.48)))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(.white.opacity(0.64), lineWidth: 0.8)
        }
        .shadow(color: .black.opacity(0.03), radius: 10, y: 5)
    }
}

struct AppearanceToggleRow: View {
    var icon: String
    var title: String
    var description: String
    @Binding var isOn: Bool
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(accent)
                .frame(width: 22)

            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(textColor)
                Text(description).font(.system(size: 11)).foregroundStyle(secondaryText.opacity(0.72)).lineLimit(1)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .toggleStyle(.switch)
                .tint(accent)
                .scaleEffect(0.85)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
    }
}

struct AppearanceSliderRow: View {
    var icon: String
    var title: String
    @Binding var value: Double
    var range: ClosedRange<Double>
    var displayValue: String
    var accent: Color
    var secondaryAccent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 8) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(accent)
                    .frame(width: 22)
                Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(textColor)
                Spacer()
                Text(displayValue)
                    .font(.system(size: 12, weight: .semibold).monospacedDigit())
                    .foregroundStyle(secondaryText.opacity(0.65))
            }
            .padding(.horizontal, 12)

            GeometryReader { proxy in
                let fraction = (value - range.lowerBound) / (range.upperBound - range.lowerBound)
                ZStack(alignment: .leading) {
                    Capsule().fill(secondaryAccent.opacity(0.15)).frame(height: 5)
                    Capsule()
                        .fill(LinearGradient(colors: [accent.opacity(0.55), accent],
                                             startPoint: .leading, endPoint: .trailing))
                        .frame(width: max(5, proxy.size.width * fraction), height: 5)
                    Circle()
                        .fill(.white)
                        .frame(width: 18, height: 18)
                        .shadow(color: .black.opacity(0.12), radius: 3, y: 1)
                        .overlay { Circle().strokeBorder(accent.opacity(0.18), lineWidth: 1) }
                        .offset(x: max(0, proxy.size.width * fraction - 9))
                }
                .frame(height: 18)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { v in
                    let t = min(max(v.location.x / max(proxy.size.width, 1), 0), 1)
                    value = range.lowerBound + t * (range.upperBound - range.lowerBound)
                })
            }
            .frame(height: 18)
            .padding(.horizontal, 12)
        }
        .padding(.vertical, 10)
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 3 – Behavior
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step3BehaviorPanel: View {
    @Binding var settings: OnboardingSettings
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 0) {
            BehaviorRow(icon: "arrow.up.left.and.arrow.down.right",
                        title: "Float Above Other Windows",
                        description: "MiniMusix stays on top of every app.",
                        isOn: $settings.floatAbove,
                        accent: accent, textColor: textColor, secondaryText: secondaryText)
            Divider().opacity(0.18).padding(.horizontal, 4)

            BehaviorRow(icon: "eye.slash",
                        title: "Hide When Playback Stops",
                        description: "Automatically hides when nothing is playing.",
                        isOn: $settings.hideOnStop,
                        accent: accent, textColor: textColor, secondaryText: secondaryText)
            Divider().opacity(0.18).padding(.horizontal, 4)

            BehaviorRow(icon: "text.line.first.and.arrowtriangle.forward",
                        title: "Show Queue Button",
                        description: "Displays the queue panel button alongside the player.",
                        isOn: $settings.showQueueButton,
                        accent: accent, textColor: textColor, secondaryText: secondaryText)
            Divider().opacity(0.18).padding(.horizontal, 4)

            BehaviorRow(icon: "quote.bubble",
                        title: "Show Lyrics Button",
                        description: "Displays the lyrics panel button alongside the player.",
                        isOn: $settings.showLyricsButton,
                        accent: accent, textColor: textColor, secondaryText: secondaryText)
            Divider().opacity(0.18).padding(.horizontal, 4)

            BehaviorRow(icon: "sunrise",
                        title: "Launch at Login",
                        description: "MiniMusix opens automatically when you log in.",
                        isOn: $settings.launchAtLogin,
                        accent: accent, textColor: textColor, secondaryText: secondaryText)
        }
        .padding(6)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(.white.opacity(0.48)))
        .overlay {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .strokeBorder(.white.opacity(0.64), lineWidth: 0.8)
        }
        .shadow(color: .black.opacity(0.03), radius: 10, y: 5)
    }
}

struct BehaviorRow: View {
    var icon: String
    var title: String
    var description: String
    @Binding var isOn: Bool
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 8, style: .continuous)
                    .fill(isOn ? accent.opacity(0.12) : Color.white.opacity(0.44))
                    .frame(width: 32, height: 32)
                Image(systemName: icon)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(isOn ? accent : textColor.opacity(0.48))
            }
            .animation(.easeOut(duration: 0.22), value: isOn)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(textColor)
                Text(description)
                    .font(.system(size: 11))
                    .foregroundStyle(secondaryText.opacity(0.72))
                    .lineLimit(1)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .toggleStyle(.switch)
                .tint(accent)
                .scaleEffect(0.85)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 4 – Lyrics
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step4LyricsPanel: View {
    @Binding var settings: OnboardingSettings
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 12) {
            // LRCLIB callout card
            LRCLIBInfoCard(accent: accent, textColor: textColor, secondaryText: secondaryText)

            // Options list
            VStack(spacing: 0) {
                BehaviorRow(icon: "quote.bubble.fill",
                            title: "Enable Lyrics",
                            description: "Fetch lyrics from LRCLIB when you open the panel.",
                            isOn: $settings.lyricsEnabled,
                            accent: accent, textColor: textColor, secondaryText: secondaryText)

                if settings.lyricsEnabled {
                    Divider().opacity(0.18).padding(.horizontal, 4)
                    BehaviorRow(icon: "waveform",
                                title: "Prefer Synced Lyrics",
                                description: "Show time-synced lyrics when available.",
                                isOn: $settings.preferSynced,
                                accent: accent, textColor: textColor, secondaryText: secondaryText)
                    Divider().opacity(0.18).padding(.horizontal, 4)
                    BehaviorRow(icon: "text.alignleft",
                                title: "Plain Lyrics Fallback",
                                description: "Fall back to plain text if synced isn't available.",
                                isOn: $settings.plainFallback,
                                accent: accent, textColor: textColor, secondaryText: secondaryText)
                }
            }
            .padding(6)
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(.white.opacity(0.48)))
            .overlay {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(.white.opacity(0.64), lineWidth: 0.8)
            }
            .animation(.spring(response: 0.42, dampingFraction: 0.84), value: settings.lyricsEnabled)
        }
    }
}

struct LRCLIBInfoCard: View {
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(accent.opacity(0.12))
                    .frame(width: 44, height: 44)
                Image(systemName: "music.note.list")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(accent)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text("Powered by LRCLIB")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundStyle(textColor)
                Text("Free, open-source lyrics. No account or API key needed. Only sends track title, artist, album, and duration.")
                    .font(.system(size: 11))
                    .foregroundStyle(secondaryText.opacity(0.78))
                    .lineSpacing(2)
                    .lineLimit(3)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(accent.opacity(0.06))
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(accent.opacity(0.18), lineWidth: 0.8)
        }
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 5 – Permissions
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step5PermissionsPanel: View {
    var launchAtLogin: Bool
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    var body: some View {
        VStack(spacing: 8) {
            PermissionCard(
                icon: "music.note",
                iconColor: Color(red: 0.85, green: 0.28, blue: 0.22),
                title: "Apple Music Access",
                description: "Lets MiniMusix read the current track and control playback via Apple Events.",
                required: false,
                accent: accent, textColor: textColor, secondaryText: secondaryText
            ) {
                if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation") {
                    NSWorkspace.shared.open(url)
                }
            }

            PermissionCard(
                icon: "network",
                iconColor: Color(red: 0.25, green: 0.47, blue: 0.85),
                title: "Network Access",
                description: "Used to fetch lyrics from LRCLIB. No personal data is sent — only track metadata.",
                required: false,
                accent: accent, textColor: textColor, secondaryText: secondaryText,
                actionLabel: "Automatic"
            ) { }

            if launchAtLogin {
                PermissionCard(
                    icon: "sunrise",
                    iconColor: Color(red: 0.52, green: 0.43, blue: 0.25),
                    title: "Launch at Login",
                    description: "Requires permission to register MiniMusix as a login item.",
                    required: false,
                    accent: accent, textColor: textColor, secondaryText: secondaryText
                ) {
                    if let url = URL(string: "x-apple.systempreferences:com.apple.LoginItems-Settings.extension") {
                        NSWorkspace.shared.open(url)
                    }
                }
            }

            PermissionCard(
                icon: "accessibility",
                iconColor: Color(red: 0.35, green: 0.48, blue: 0.36),
                title: "Accessibility",
                description: "Only needed for advanced global keyboard shortcuts. Fully optional.",
                required: false,
                accent: accent, textColor: textColor, secondaryText: secondaryText,
                actionLabel: "Optional"
            ) { }
        }
    }
}

struct PermissionCard: View {
    var icon: String
    var iconColor: Color
    var title: String
    var description: String
    var required: Bool
    var accent: Color
    var textColor: Color
    var secondaryText: Color
    var actionLabel: String = "Open Settings"
    var action: () -> Void

    @State private var hovered = false

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(iconColor.opacity(0.13))
                    .frame(width: 40, height: 40)
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(iconColor)
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(title)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(textColor)
                    if required {
                        Text("Required")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 7).padding(.vertical, 2)
                            .background(Capsule().fill(iconColor.opacity(0.72)))
                    }
                }
                Text(description)
                    .font(.system(size: 11))
                    .foregroundStyle(secondaryText.opacity(0.75))
                    .lineSpacing(1.5)
                    .lineLimit(2)
            }

            Spacer()

            // Action button
            Button(action: action) {
                Text(actionLabel)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundStyle(accent)
                    .padding(.horizontal, 12)
                    .frame(height: 28)
                    .background(Capsule().fill(accent.opacity(0.10)))
                    .overlay { Capsule().strokeBorder(accent.opacity(0.22), lineWidth: 0.7) }
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.white.opacity(hovered ? 0.52 : 0.38))
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(.white.opacity(hovered ? 0.58 : 0.44), lineWidth: 0.8)
        }
        .onHover { hovered = $0 }
        .animation(.easeOut(duration: 0.20), value: hovered)
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Step 6 – Final Preview
// MARK: ──────────────────────────────────────────────────────────────────────

struct Step6FinalPanel: View {
    var accent: Color
    var textColor: Color
    var secondaryText: Color

    private let features: [(String, String)] = [
        ("Floating player",          "music.note.tv"),
        ("Real-time lyrics",         "quote.bubble"),
        ("Queue management",         "text.line.first.and.arrowtriangle.forward"),
        ("Album-tinted glass",       "paintpalette"),
        ("Always on top",            "arrow.up.left.and.arrow.down.right"),
    ]

    var body: some View {
        VStack(spacing: 14) {
            // Summary card
            VStack(spacing: 10) {
                ForEach(features, id: \.0) { feature in
                    HStack(spacing: 12) {
                        Image(systemName: feature.1)
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(accent)
                            .frame(width: 20)
                        Text(feature.0)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(textColor)
                        Spacer()
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundStyle(accent.opacity(0.70))
                    }
                    if feature.0 != features.last?.0 {
                        Divider().opacity(0.18)
                    }
                }
            }
            .padding(16)
            .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(.white.opacity(0.48)))
            .overlay {
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .strokeBorder(.white.opacity(0.64), lineWidth: 0.8)
            }
            .shadow(color: .black.opacity(0.03), radius: 10, y: 5)

            // Closing note
            Text("MiniMusix will float at the bottom of your screen.\nDouble-tap the pill anytime to toggle compact ↔ expanded.")
                .font(.system(size: 11.5))
                .foregroundStyle(secondaryText.opacity(0.68))
                .multilineTextAlignment(.center)
                .lineSpacing(2)
                .padding(.horizontal, 4)
        }
    }
}

// MARK: ──────────────────────────────────────────────────────────────────────
// MARK: Shared UI Atoms
// MARK: ──────────────────────────────────────────────────────────────────────

struct FeatureChip: View {
    var label: String
    var accent: Color
    var textColor: Color

    var body: some View {
        Text(label)
            .font(.system(size: 11.5, weight: .semibold))
            .foregroundStyle(textColor.opacity(0.66))
            .padding(.horizontal, 12).padding(.vertical, 5)
            .background(Capsule().fill(.white.opacity(0.44)))
            .overlay { Capsule().strokeBorder(.white.opacity(0.58), lineWidth: 0.7) }
    }
}

struct PreviewSectionLabel: View {
    var text: String
    var accent: Color

    var body: some View {
        HStack(spacing: 7) {
            Rectangle().fill(accent.opacity(0.38)).frame(width: 20, height: 1)
            Text(text)
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(accent.opacity(0.58))
                .tracking(1.6)
            Rectangle().fill(accent.opacity(0.38)).frame(width: 20, height: 1)
        }
    }
}

struct WaveformDecoration: View {
    var color: Color
    private let amplitudes: [CGFloat] = [0.55,0.90,0.70,1.0,0.65,0.85,0.45,0.95,0.75,0.60,0.88,0.50,0.78,0.92,0.62]

    var body: some View {
        GeometryReader { geo in
            let barW: CGFloat = 3, gap: CGFloat = 5
            let total = Int((geo.size.width + gap) / (barW + gap))
            let midY  = geo.size.height / 2
            ForEach(0..<total, id: \.self) { i in
                let amp = amplitudes[i % amplitudes.count]
                Capsule()
                    .fill(color)
                    .frame(width: barW, height: amp * geo.size.height * 0.85)
                    .position(x: CGFloat(i) * (barW + gap) + barW / 2, y: midY)
                    .opacity(0.5 + amp * 0.5)
            }
        }
    }
}

// MARK: - Compatibility stubs (kept so existing callsites still compile)

struct OnboardingGlassStyleCompat {}  // namespace guard

struct OnboardingOptionsPanel: View {
    @Binding var previewMode: MiniPlayerMode
    @Binding var glassStyle: OnboardingGlassStyle
    @Binding var previewTint: Double
    var accent: Color; var secondaryAccent: Color; var textColor: Color; var secondaryText: Color

    var body: some View {
        VStack(spacing: 14) {
            OptionRow(icon: "rectangle.split.2x1", title: "View Mode",
                      accent: accent, textColor: textColor, secondaryText: secondaryText) {
                HStack(spacing: 7) {
                    ForEach([MiniPlayerMode.compact, MiniPlayerMode.expanded], id: \.self) { mode in
                        ModeChip(label: mode.rawValue, selected: previewMode == mode,
                                 accent: accent, textColor: textColor) {
                            withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) { previewMode = mode }
                        }
                    }
                }
            }
            OptionRow(icon: "sparkle", title: "Glass", accent: accent,
                      textColor: textColor, secondaryText: secondaryText) {
                HStack(spacing: 7) {
                    ForEach(OnboardingGlassStyle.allCases) { style in
                        ModeChip(label: style.rawValue, selected: glassStyle == style,
                                 accent: accent, textColor: textColor) {
                            withAnimation(.easeOut(duration: 0.24)) { glassStyle = style }
                        }
                    }
                }
            }
            OptionRow(icon: "paintpalette", title: "Album Tint",
                      value: "\(Int(previewTint / 0.12 * 100))%",
                      accent: accent, textColor: textColor, secondaryText: secondaryText) {
                TintSlider(value: $previewTint, accent: accent, secondaryAccent: secondaryAccent)
            }
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(.white.opacity(0.52)))
        .overlay { RoundedRectangle(cornerRadius: 20, style: .continuous).strokeBorder(.white.opacity(0.68), lineWidth: 0.8) }
        .shadow(color: .black.opacity(0.04), radius: 12, y: 6)
    }
}

struct OptionRow<Content: View>: View {
    var icon: String; var title: String; var value: String? = nil
    var accent: Color; var textColor: Color; var secondaryText: Color
    @ViewBuilder var content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: icon).font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(accent).frame(width: 18)
                Text(title).font(.system(size: 13, weight: .semibold)).foregroundStyle(textColor)
                if let value { Spacer()
                    Text(value).font(.system(size: 12, weight: .semibold).monospacedDigit())
                        .foregroundStyle(secondaryText.opacity(0.65)) }
            }
            content()
        }
    }
}

struct ModeChip: View {
    var label: String; var selected: Bool; var accent: Color; var textColor: Color; var action: () -> Void
    @State private var hovered = false
    var body: some View {
        Button(action: action) {
            Text(label).font(.system(size: 12.5, weight: .semibold))
                .foregroundStyle(selected ? .white : textColor.opacity(0.72))
                .padding(.horizontal, 14).frame(height: 32)
                .background(Capsule().fill(selected ? accent : Color.white.opacity(hovered ? 0.55 : 0.38)))
                .overlay { Capsule().strokeBorder(selected ? .white.opacity(0.22) : .white.opacity(0.52), lineWidth: 0.7) }
                .shadow(color: selected ? accent.opacity(0.18) : .clear, radius: 6, y: 3)
                .scaleEffect(hovered ? 1.04 : 1.0)
        }
        .buttonStyle(.plain).onHover { hovered = $0 }
        .animation(.spring(response: 0.24, dampingFraction: 0.72), value: hovered)
    }
}

struct TintSlider: View {
    @Binding var value: Double; var accent: Color; var secondaryAccent: Color
    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(secondaryAccent.opacity(0.14)).frame(height: 6)
                Capsule().fill(LinearGradient(colors: [accent.opacity(0.55), accent],
                                              startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(6, proxy.size.width * value / 0.12), height: 6)
                Circle().fill(.white).frame(width: 20, height: 20)
                    .shadow(color: .black.opacity(0.13), radius: 4, y: 2)
                    .overlay { Circle().strokeBorder(accent.opacity(0.20), lineWidth: 1) }
                    .offset(x: max(0, proxy.size.width * value / 0.12 - 10))
            }
            .frame(height: 20).contentShape(Rectangle())
            .gesture(DragGesture(minimumDistance: 0).onChanged { v in
                value = min(max(v.location.x / max(proxy.size.width, 1), 0), 1) * 0.12
            })
        }
        .frame(height: 20)
    }
}

struct OnboardingSegmentedControl<Option: Hashable>: View {
    var title: String; @Binding var selection: Option
    var options: [Option]; var label: (Option) -> String
    var accent: Color; var textColor: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.callout.weight(.semibold)).foregroundStyle(textColor)
            HStack(spacing: 8) {
                ForEach(options, id: \.self) { option in
                    let sel = option == selection
                    Button { withAnimation(.spring(response: 0.42, dampingFraction: 0.84)) { selection = option } }
                    label: {
                        Text(label(option)).font(.callout.weight(.semibold)).lineLimit(1)
                            .frame(maxWidth: .infinity).frame(height: 40)
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(sel ? .white : textColor.opacity(0.76))
                    .background(sel ? accent : Color.white.opacity(0.36), in: Capsule())
                    .overlay { Capsule().strokeBorder(.white.opacity(sel ? 0.22 : 0.5), lineWidth: 0.7) }
                }
            }
        }
    }
}
