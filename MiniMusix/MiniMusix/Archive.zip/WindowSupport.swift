import AppKit
import SwiftUI
import Combine

struct WindowConfigurator: NSViewRepresentable {
    var alwaysOnTop: Bool
    var hiddenFromCapture: Bool
    var size: CGSize
    var isOnboarding: Bool
    var hiddenForLockscreen: Bool
    var frameDidChange: (NSRect) -> Void = { _ in }

    func makeNSView(context: Context) -> NSView {
        let view = NSView()
        DispatchQueue.main.async {
            configure(window: view.window)
        }
        return view
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        DispatchQueue.main.async {
            configure(window: nsView.window)
        }
    }

    private func configure(window: NSWindow?) {
        guard let window else { return }
        window.title = "MiniMusix"
        window.isMovableByWindowBackground = true
        window.titleVisibility = .hidden
        window.titlebarAppearsTransparent = true
        window.isOpaque = isOnboarding
        window.backgroundColor = isOnboarding ? NSColor(red: 0.93, green: 0.92, blue: 0.88, alpha: 1) : .clear
        window.hasShadow = isOnboarding || !hiddenForLockscreen
        window.alphaValue = hiddenForLockscreen ? 0 : 1
        window.level = windowLevel
        window.collectionBehavior.insert([.fullScreenAuxiliary, .canJoinAllSpaces, .stationary, .transient, .ignoresCycle])

        if isOnboarding {
            window.styleMask.insert([.titled, .closable, .miniaturizable])
            window.styleMask.remove(.borderless)
            window.standardWindowButton(.closeButton)?.isHidden = false
            window.standardWindowButton(.miniaturizeButton)?.isHidden = false
            window.standardWindowButton(.zoomButton)?.isHidden = false
        } else {
            window.styleMask = [.borderless]
            window.standardWindowButton(.closeButton)?.isHidden = true
            window.standardWindowButton(.miniaturizeButton)?.isHidden = true
            window.standardWindowButton(.zoomButton)?.isHidden = true
        }

        if hiddenFromCapture {
            window.sharingType = .none
        } else {
            window.sharingType = .readOnly
        }

        guard let screen = window.screen ?? NSScreen.main else { return }
        let visible = screen.visibleFrame
        let origin = CGPoint(
            x: visible.midX - size.width / 2,
            y: isOnboarding ? visible.midY - size.height / 2 : visible.minY + 28
        )
        let frame = NSRect(origin: origin, size: size)
        window.setFrame(frame, display: true, animate: true)

        if !hiddenForLockscreen {
            frameDidChange(frame)
        }
    }

    private var windowLevel: NSWindow.Level {
        if isOnboarding {
            return .normal
        }

        return alwaysOnTop ? .floating : .normal
    }
}

@MainActor
final class LockScreenSurfaceController: ObservableObject {
    private var panel: LockScreenSurfacePanel?
    private var hostingView: NSHostingView<LockScreenSurfaceView>?
    private var lastTargetFrame: NSRect = .zero

    func present(
        store: NowPlayingStore,
        presentation: MiniPlayerPresentationController,
        from sourceFrame: NSRect,
        reduceMotion: Bool,
        close: @escaping () -> Void
    ) {
        let panel = panel ?? makePanel(hiddenFromCapture: store.settings.hideFromScreenCapture)
        self.panel = panel

        let targetFrame = targetFrame(for: presentation, near: sourceFrame)
        lastTargetFrame = targetFrame

        if !panel.isVisible {
            panel.setFrame(sourceFrame.isEmpty ? collapsedFrame(for: targetFrame) : sourceFrame, display: false)
            panel.alphaValue = 0
        }

        updateContent(
            panel: panel,
            store: store,
            presentation: presentation,
            close: close
        )

        panel.collectionBehavior.insert([.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle])
        panel.orderFrontRegardless()
        panel.makeKeyAndOrderFront(nil)

        place(panel, at: targetFrame, alpha: 1, reduceMotion: reduceMotion)
    }

    func update(
        store: NowPlayingStore,
        presentation: MiniPlayerPresentationController,
        reduceMotion: Bool,
        close: @escaping () -> Void
    ) {
        guard let panel else { return }
        if !panel.isVisible {
            panel.orderFrontRegardless()
        }

        updateContent(
            panel: panel,
            store: store,
            presentation: presentation,
            close: close
        )

        let targetFrame = targetFrame(for: presentation, near: lastTargetFrame)
        lastTargetFrame = targetFrame
        place(panel, at: targetFrame, alpha: 1, reduceMotion: reduceMotion)
    }

    func dismiss(to destinationFrame: NSRect, reduceMotion: Bool) {
        guard let panel else { return }
        let finalFrame = destinationFrame.isEmpty ? collapsedFrame(for: lastTargetFrame) : destinationFrame

        if reduceMotion {
            panel.orderOut(nil)
            self.panel = nil
            hostingView = nil
            return
        }

        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.34
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            panel.animator().alphaValue = 0
            panel.animator().setFrame(finalFrame, display: true)
        } completionHandler: {
            Task { @MainActor in
                panel.orderOut(nil)
                self.panel = nil
                self.hostingView = nil
            }
        }
    }

    private func makePanel(hiddenFromCapture: Bool) -> LockScreenSurfacePanel {
        let panel = LockScreenSurfacePanel(
            contentRect: .zero,
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )

        panel.title = "MiniMusix Lockscreen Surface"
        panel.titleVisibility = .hidden
        panel.titlebarAppearsTransparent = true
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.contentView?.wantsLayer = true
        panel.contentView?.layer?.backgroundColor = NSColor.clear.cgColor
        panel.hasShadow = false
        panel.hidesOnDeactivate = false
        panel.isFloatingPanel = true
        panel.becomesKeyOnlyIfNeeded = false
        panel.isMovable = false
        panel.isMovableByWindowBackground = false
        panel.isReleasedWhenClosed = false
        panel.level = NSWindow.Level(rawValue: Int(CGShieldingWindowLevel()))
        panel.collectionBehavior = [
            .canJoinAllSpaces,
            .fullScreenAuxiliary,
            .stationary,
            .ignoresCycle
        ]
        panel.sharingType = hiddenFromCapture ? .none : .readOnly
        panel.standardWindowButton(.closeButton)?.isHidden = true
        panel.standardWindowButton(.miniaturizeButton)?.isHidden = true
        panel.standardWindowButton(.zoomButton)?.isHidden = true

        return panel
    }

    private func updateContent(
        panel: LockScreenSurfacePanel,
        store: NowPlayingStore,
        presentation: MiniPlayerPresentationController,
        close: @escaping () -> Void
    ) {
        let rootView = LockScreenSurfaceView(
            store: store,
            presentation: presentation,
            close: close
        )

        if let hostingView {
            hostingView.rootView = rootView
        } else {
            let hostingView = NSHostingView(rootView: rootView)
            hostingView.frame = NSRect(origin: .zero, size: panel.frame.size)
            hostingView.autoresizingMask = [.width, .height]
            hostingView.wantsLayer = true
            hostingView.layer?.backgroundColor = NSColor.clear.cgColor
            panel.contentView = hostingView
            hostingView.frame = NSRect(origin: .zero, size: panel.contentView?.bounds.size ?? panel.frame.size)
            self.hostingView = hostingView
        }
    }

    private func place(_ panel: LockScreenSurfacePanel, at frame: NSRect, alpha: CGFloat, reduceMotion: Bool) {
        if reduceMotion {
            panel.setFrame(frame, display: true)
            panel.alphaValue = alpha
            panel.orderFrontRegardless()
            return
        }

        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.58
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            panel.animator().alphaValue = alpha
            panel.animator().setFrame(frame, display: true)
        }
    }

    private func targetFrame(for presentation: MiniPlayerPresentationController, near sourceFrame: NSRect) -> NSRect {
        let size = presentation.lockscreenLyricsVisible
            ? CGSize(width: 1060, height: 650)
            : CGSize(width: 720, height: 650)
        let screen = NSScreen.screens.first { $0.frame.intersects(sourceFrame) } ?? NSScreen.main
        let visible = screen?.frame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)

        return NSRect(
            x: visible.midX - size.width / 2,
            y: visible.midY - size.height / 2,
            width: size.width,
            height: size.height
        )
    }

    private func collapsedFrame(for targetFrame: NSRect) -> NSRect {
        NSRect(
            x: targetFrame.midX - 280,
            y: targetFrame.minY + 28,
            width: 560,
            height: 120
        )
    }
}

final class LockScreenSurfacePanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }

    override init(contentRect: NSRect, styleMask style: NSWindow.StyleMask, backing backingStoreType: NSWindow.BackingStoreType, defer flag: Bool) {
        super.init(contentRect: contentRect, styleMask: style, backing: backingStoreType, defer: flag)
        self.isOpaque = false
        self.backgroundColor = .clear
    }
}
